# Speed Run — Firebase foundation

This version is the first Firebase-integrated foundation of Speed Run.

## Included
- Firebase Android app registration for `com.speedrun.delivery`.
- `google-services.json` in `app/`.
- Google Services Gradle plugin 4.5.0.
- Firebase Android BoM 34.19.0.
- Firebase Authentication, Firestore, Storage, Analytics, and Cloud Messaging dependencies.
- Initial Firestore and Storage security rules.
- Internet/location/notification permissions required by the planned features.

## Important
Do not rename `google-services.json`. Do not change the application ID.

## Before production
1. Enable Email/Password and Phone providers in Firebase Authentication.
2. Configure the allowed SMS regions and verify the app's SHA-1/SHA-256 fingerprints for phone auth.
3. Create Firestore in production mode and deploy `firestore.rules`.
4. Enable Cloud Storage and deploy `storage.rules`.
5. Create the first owner account, then assign its UID the `OWNER` role in `/roles/{uid}`. Never allow the public app to self-select OWNER/MANAGER/SUPERVISOR.
6. Configure Firebase Cloud Messaging and Google Maps/Places keys in the next phase.
7. Create a release signing key and build an Android App Bundle (`.aab`) before Play Console submission.


Build note: Compose BOM is pinned to the stable 2026.09.00 release.
