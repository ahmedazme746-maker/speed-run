package com.speedrun.delivery

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

private val Orange = Color(0xFFFF6A00)
private val Black = Color(0xFF101010)
private val Soft = Color(0xFFF5F5F5)

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER, OWNER }

data class Restaurant(val name: String, val category: String, val city: String, val rating: Double)

private val restaurants = listOf(
    Restaurant("Speed Run Kitchen", "برجر", "الرياض", 4.8),
    Restaurant("مطعم الخليج", "مشويات", "الرياض", 4.6),
    Restaurant("مطعم النخبة", "وجبات سريعة", "جدة", 4.7),
    Restaurant("مطعم مذاق", "مأكولات عربية", "الدمام", 4.5)
)

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

@Composable
fun SpeedRunApp() {
    var lang by remember { mutableStateOf("العربية") }
    var role by remember { mutableStateOf<Role?>(null) }
    var logged by remember { mutableStateOf(auth.currentUser != null) }
    var loading by remember { mutableStateOf(auth.currentUser != null) }

    LaunchedEffect(Unit) {
        auth.currentUser?.let { user ->
            loadRole(user.uid, Role.CUSTOMER) { resolved ->
                role = resolved
                logged = true
                loading = false
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Orange, background = Soft)) {
        when {
            loading -> LoadingScreen()
            role == null -> RoleScreen(lang, { lang = it }) { role = it }
            !logged -> AuthScreen(
                role = role!!,
                lang = lang,
                back = { role = null },
                onSuccess = { resolved -> role = resolved; logged = true }
            )
            role == Role.CUSTOMER -> CustomerHome(onLogout = { auth.signOut(); logged = false; role = null })
            role == Role.DRIVER -> DriverHome(onLogout = { auth.signOut(); logged = false; role = null })
            role == Role.RESTAURANT -> RestaurantHome(onLogout = { auth.signOut(); logged = false; role = null })
            role == Role.SUPERVISOR -> AdminHome("المشرف", onLogout = { auth.signOut(); logged = false; role = null })
            role == Role.MANAGER -> AdminHome("المدير", onLogout = { auth.signOut(); logged = false; role = null })
            else -> AdminHome("المالك الرئيسي", onLogout = { auth.signOut(); logged = false; role = null })
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContent { SpeedRunApp() }
    }
}

@Composable
fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("SPEED RUN", color = Orange, fontSize = 38.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(16.dp))
            CircularProgressIndicator(color = Orange)
            Spacer(Modifier.height(12.dp))
            Text("جاري تجهيز حسابك...", color = Color.LightGray)
        }
    }
}

@Composable
fun Header(title: String, sub: String, onLogout: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().background(Black).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("SPEED RUN", color = Orange, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color.LightGray, fontSize = 12.sp)
        }
        if (onLogout != null) {
            IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "خروج", tint = Color.White) }
        }
    }
}

@Composable
fun RoleScreen(lang: String, onLang: (String) -> Unit, onRole: (Role) -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Black).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(35.dp))
        Text("SPEED RUN", color = Orange, fontSize = 40.sp, fontWeight = FontWeight.Black)
        Text("طلباتك... توصل أسرع", color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.height(25.dp))
        Text("اللغة / Language", color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(8.dp)) {
            listOf("العربية", "English", "اردو", "বাংলা").forEach {
                FilterChip(selected = lang == it, onClick = { onLang(it) }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(20.dp))
        RoleButton("العميل", "طلبات الطعام وتتبع الطلب", Icons.Default.Person) { onRole(Role.CUSTOMER) }
        RoleButton("السائق / المندوب", "الطلبات والخريطة والأرباح", Icons.Default.DirectionsCar) { onRole(Role.DRIVER) }
        RoleButton("المطعم", "إدارة القائمة والطلبات", Icons.Default.Store) { onRole(Role.RESTAURANT) }
        Spacer(Modifier.height(12.dp))
        Text(
            "حسابات المشرف والمدير والمالك تُمنح من لوحة الإدارة فقط",
            color = Color.Gray,
            fontSize = 11.sp
        )
    }
}

@Composable
fun RoleButton(t: String, s: String, icon: androidx.compose.ui.graphics.vector.ImageVector, click: () -> Unit) {
    Button(
        onClick = click,
        modifier = Modifier.fillMaxWidth().padding(4.dp).height(62.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Orange),
        shape = RoundedCornerShape(16.dp)
    ) {
        Icon(icon, null)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(t, fontWeight = FontWeight.Bold)
            Text(s, fontSize = 11.sp)
        }
    }
}

private enum class AuthMode { EMAIL, PHONE }

@Composable
fun AuthScreen(role: Role, lang: String, back: () -> Unit, onSuccess: (Role) -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var mode by remember { mutableStateOf(AuthMode.EMAIL) }
    var createAccount by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun finish(userUid: String) {
        saveUserProfile(userUid, role) {
            loadRole(userUid, role) { resolved ->
                logEvent(context, if (createAccount) "sign_up" else "login", resolved)
                onSuccess(resolved)
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Black).padding(22.dp)) {
        TextButton(onClick = back) { Text("رجوع", color = Orange) }
        Spacer(Modifier.height(18.dp))
        Text("SPEED RUN", color = Orange, fontSize = 34.sp, fontWeight = FontWeight.Black)
        Text(roleTitle(role), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text(lang, color = Color.Gray)
        Spacer(Modifier.height(18.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == AuthMode.EMAIL, onClick = { mode = AuthMode.EMAIL; message = null }, label = { Text("البريد الإلكتروني") })
            FilterChip(selected = mode == AuthMode.PHONE, onClick = { mode = AuthMode.PHONE; message = null }, label = { Text("رقم الجوال") })
        }

        Spacer(Modifier.height(18.dp))
        if (mode == AuthMode.EMAIL) {
            OutlinedTextField(
                value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("البريد الإلكتروني") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("كلمة المرور") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true
            )
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { createAccount = !createAccount }) {
                Text(if (createAccount) "لديك حساب؟ تسجيل الدخول" else "إنشاء حساب جديد", color = Orange)
            }
            Button(
                onClick = {
                    if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                        message = "اكتب بريدًا إلكترونيًا صحيحًا"
                        return@Button
                    }
                    if (password.length < 6) {
                        message = "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
                        return@Button
                    }
                    busy = true
                    val task = if (createAccount) auth.createUserWithEmailAndPassword(email.trim(), password) else auth.signInWithEmailAndPassword(email.trim(), password)
                    task.addOnCompleteListener { result ->
                        busy = false
                        if (result.isSuccessful && result.result?.user != null) finish(result.result!!.user!!.uid)
                        else message = result.exception?.localizedMessage ?: "تعذر إكمال العملية"
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(55.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Orange)
            ) { Text(if (createAccount) "إنشاء الحساب" else "تسجيل الدخول", fontWeight = FontWeight.Bold) }
        } else {
            OutlinedTextField(
                value = phone, onValueChange = { phone = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("رقم الجوال بصيغة دولية مثل +9665XXXXXXXX") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true
            )
            Spacer(Modifier.height(10.dp))
            if (verificationId == null) {
                Button(
                    onClick = {
                        if (activity == null || !phone.trim().startsWith("+")) {
                            message = "اكتب رقم الجوال بصيغة دولية، وتأكد من تشغيل التطبيق على جهاز يدعم Google Play"
                            return@Button
                        }
                        busy = true
                        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                auth.signInWithCredential(credential).addOnCompleteListener { result ->
                                    busy = false
                                    if (result.isSuccessful && result.result?.user != null) finish(result.result!!.user!!.uid)
                                    else message = result.exception?.localizedMessage ?: "تعذر تسجيل الدخول برقم الجوال"
                                }
                            }
                            override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                                busy = false
                                message = e.localizedMessage ?: "فشل إرسال رمز التحقق"
                            }
                            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                                verificationId = id
                                busy = false
                                message = "تم إرسال رمز التحقق"
                            }
                        }
                        val options = PhoneAuthOptions.newBuilder(auth)
                            .setPhoneNumber(phone.trim())
                            .setTimeout(60L, TimeUnit.SECONDS)
                            .setActivity(activity)
                            .setCallbacks(callbacks)
                            .build()
                        PhoneAuthProvider.verifyPhoneNumber(options)
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange)
                ) { Text(if (busy) "جاري الإرسال..." else "إرسال رمز التحقق") }
            } else {
                OutlinedTextField(value = otp, onValueChange = { otp = it }, modifier = Modifier.fillMaxWidth(), label = { Text("رمز التحقق") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        val id = verificationId ?: return@Button
                        busy = true
                        auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp.trim())).addOnCompleteListener { result ->
                            busy = false
                            if (result.isSuccessful && result.result?.user != null) finish(result.result!!.user!!.uid)
                            else message = result.exception?.localizedMessage ?: "رمز التحقق غير صحيح"
                        }
                    },
                    enabled = !busy && otp.length >= 4,
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange)
                ) { Text("تأكيد وتسجيل الدخول") }
            }
        }

        message?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = if (it.contains("تم")) Color(0xFF5CE1A4) else Color(0xFFFF8A80), fontSize = 12.sp)
        }
    }
}

private fun roleTitle(role: Role) = when (role) {
    Role.CUSTOMER -> "حساب العميل"
    Role.DRIVER -> "حساب السائق / المندوب"
    Role.RESTAURANT -> "حساب المطعم"
    Role.SUPERVISOR -> "حساب المشرف"
    Role.MANAGER -> "حساب المدير"
    Role.OWNER -> "حساب المالك الرئيسي"
}

private fun saveUserProfile(uid: String, selectedRole: Role, done: () -> Unit = {}) {
    val user = auth.currentUser ?: return done()
    val data = hashMapOf<String, Any>(
        "uid" to uid,
        "email" to (user.email ?: ""),
        "phoneNumber" to (user.phoneNumber ?: ""),
        "requestedRole" to selectedRole.name,
        "updatedAt" to FieldValue.serverTimestamp()
    )
    db.collection("users").document(uid).set(data, com.google.firebase.firestore.SetOptions.merge())
        .addOnCompleteListener {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
                db.collection("users").document(uid).set(mapOf("fcmToken" to token), com.google.firebase.firestore.SetOptions.merge())
            }
            done()
        }
}

private fun loadRole(uid: String, fallback: Role, done: (Role) -> Unit) {
    db.collection("roles").document(uid).get().addOnSuccessListener { snap ->
        val roleName = snap.getString("role")
        val resolved = roleName?.let { runCatching { Role.valueOf(it) }.getOrNull() } ?: fallback
        done(resolved)
    }.addOnFailureListener { done(fallback) }
}

private fun logEvent(context: android.content.Context, name: String, role: Role) {
    val analytics = FirebaseAnalytics.getInstance(context)
    analytics.logEvent(name, android.os.Bundle().apply { putString("role", role.name) })
}

@Composable
fun CustomerHome(onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("تطبيق العميل", "مطاعم مختارة داخل السعودية", onLogout)
        LazyColumn(Modifier.padding(14.dp)) {
            item { Text("المطاعم القريبة", fontSize = 22.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)) }
            items(restaurants) { RestaurantCard(it) }
        }
    }
}

@Composable
fun DriverHome(onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("تطبيق السائق / المندوب", "تتبع الطلبات والتوصيل", onLogout)
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Stat("حالة السائق", "متاح لاستقبال الطلبات") }
            item { Stat("طلبات اليوم", "0") }
            item { Stat("أرباح اليوم", "0 ريال") }
            item { Stat("التقييم", "جديد") }
            item { Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("عرض الطلبات القريبة") } }
        }
    }
}

@Composable
fun RestaurantHome(onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("بوابة المطعم", "الطلبات والقائمة والعروض", onLogout)
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Stat("طلبات اليوم", "0") }
            item { Stat("المبيعات", "0 ريال") }
            item { Stat("التقييم", "جديد") }
            item { Stat("الحالة", "مفتوح") }
        }
    }
}

@Composable
fun AdminHome(title: String, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("لوحة $title", "صلاحيات منفصلة + سجل كامل للعمليات", onLogout)
        LazyColumn(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Stat("إجمالي الطلبات", "0") }
            item { Stat("المستخدمون", "0") }
            item { Stat("المطاعم", "0") }
            item { Stat("السائقون النشطون", "0") }
            item { Stat("الإيرادات", "0 ريال") }
            item { AdminItem("إدارة المستخدمين", Icons.Default.People) }
            item { AdminItem("إدارة السائقين", Icons.Default.DirectionsCar) }
            item { AdminItem("إدارة المطاعم", Icons.Default.Store) }
            item { AdminItem("مراقبة الطلبات", Icons.Default.LocationOn) }
            item { AdminItem("التقارير والإحصائيات", Icons.Default.BarChart) }
            item { AdminItem("الكوبونات والعروض", Icons.Default.LocalOffer) }
            item { AdminItem("الصلاحيات وسجل العمليات", Icons.Default.Security) }
        }
    }
}

@Composable
fun RestaurantCard(r: Restaurant) {
    Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(Modifier.size(55.dp), shape = RoundedCornerShape(12.dp), color = Orange) {
                Box(contentAlignment = Alignment.Center) { Text("SR", fontWeight = FontWeight.Black) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, fontWeight = FontWeight.Bold)
                Text("${r.category} • ${r.city}", color = Color.Gray, fontSize = 12.sp)
                Text("⭐ ${r.rating}", color = Orange)
            }
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}

@Composable
fun Stat(t: String, v: String) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(t, color = Color.Gray)
            Text(v, color = Orange, fontSize = 24.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun AdminItem(t: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Orange)
            Spacer(Modifier.width(12.dp))
            Text(t, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}
