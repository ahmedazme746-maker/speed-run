# Speed Run V5 — Delivery Platform Foundation

نسخة V5 معاد تنظيمها حول تجربة Delivery حقيقية بدل شاشة اختيار أدوار إدارية.

## أهم ما تم تطبيقه
- واجهة دخول عامة: عميل / سائق-مندوب / مطعم فقط.
- حسابات OWNER / MANAGER / SUPERVISOR لا تظهر للعامة.
- Email/Password + Phone OTP.
- السائق والمطعم يقدمان طلب انضمام ويظلان Pending حتى اعتماد المالك.
- Customer home: عروض، تصنيفات، مطاعم، تفاصيل، إنشاء طلب، طلباتي، مفضلة، حسابي.
- Driver: online/offline، استقبال وقبول الطلبات.
- Restaurant: فتح/إغلاق، متابعة الطلبات وتحديث حالتها.
- Owner/Manager/Supervisor dashboard منفصلة.
- Customer ↔ Driver chat مرتبط بالطلب.
- Firestore rules مبدئية للصلاحيات والخصوصية.
- Firebase Storage/FCM dependencies موجودة من V4.
- versionCode 2 / versionName 2.0.

## ملاحظات مهمة
هذه V5 هي أساس وظيفي منظم وليست ادعاء أن كل خدمات الإنتاج (Maps، الدفع، المكالمات، FCM server-side، نظام المطاعم الكامل، الصور الحقيقية، الكوبونات والتقارير المتقدمة) مكتملة. يتم استكمالها فوق هذا الأساس مع اختبار كل مسار قبل Play Store.

## Firebase
فعّل Email/Password وPhone في Authentication، وفعّل Storage بعد Blaze، ثم انشر firestore.rules وstorage.rules.
