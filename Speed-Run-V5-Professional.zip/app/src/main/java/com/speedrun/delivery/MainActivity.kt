
package com.speedrun.delivery

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

private val Orange = Color(0xFFFF6A00)
private val OrangeDark = Color(0xFFE95700)
private val Black = Color(0xFF0D0D0D)
private val Card = Color(0xFF171717)
private val Muted = Color(0xFF9B9B9B)
private val Green = Color(0xFF39C47A)
private val Red = Color(0xFFE85D5D)

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER, OWNER }
enum class PublicRole { CUSTOMER, DRIVER, RESTAURANT }

data class Restaurant(
    val id: String,
    val ownerId: String = "",
    val name: String,
    val category: String,
    val city: String,
    val rating: Double = 0.0,
    val eta: String = "20–35 دقيقة",
    val open: Boolean = true
)
data class Order(
    val id: String,
    val customerId: String = "",
    val driverId: String = "",
    val restaurantId: String = "",
    val restaurantName: String = "",
    val status: String = "NEW",
    val total: Double = 0.0,
    val address: String = "",
    val createdAt: Long = 0L
)
data class ChatMessage(val id: String, val senderId: String, val text: String, val createdAt: Long)

@Composable
fun SpeedRunTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange, secondary = Orange,
            background = Black, surface = Card,
            onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedRunTheme { SpeedRunApp() } }
    }
}

@Composable
fun SpeedRunApp() {
    var language by remember { mutableStateOf("العربية") }
    var publicRole by remember { mutableStateOf<PublicRole?>(null) }
    var role by remember { mutableStateOf<Role?>(null) }
    var logged by remember { mutableStateOf(auth.currentUser != null) }
    var loading by remember { mutableStateOf(auth.currentUser != null) }
    var pending by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        auth.currentUser?.uid?.let { uid ->
            resolveRole(uid) { resolved, isPending ->
                role = resolved; pending = isPending; logged = true; loading = false
            }
        } ?: run { loading = false }
    }

    if (loading) return LoadingScreen()

    when {
        !logged -> {
            if (publicRole == null) {
                WelcomeScreen(language, { language = it }) { publicRole = it }
            } else {
                AuthScreen(
                    selected = publicRole!!, language = language,
                    onBack = { publicRole = null },
                    onSuccess = { resolved, isPending ->
                        role = resolved; pending = isPending; logged = true
                    }
                )
            }
        }
        pending -> PendingScreen(onLogout = {
            auth.signOut(); logged = false; publicRole = null; role = null; pending = false
        })
        role == Role.CUSTOMER -> CustomerApp(language) { auth.signOut(); logged = false; role = null }
        role == Role.DRIVER -> DriverApp { auth.signOut(); logged = false; role = null }
        role == Role.RESTAURANT -> RestaurantApp { auth.signOut(); logged = false; role = null }
        role == Role.OWNER -> StaffApp("المالك الرئيسي", true) { auth.signOut(); logged = false; role = null }
        role == Role.MANAGER -> StaffApp("المدير", false) { auth.signOut(); logged = false; role = null }
        role == Role.SUPERVISOR -> StaffApp("المشرف", false) { auth.signOut(); logged = false; role = null }
        else -> PendingScreen(onLogout = { auth.signOut(); logged = false; role = null })
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize().background(Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Logo()
            Spacer(Modifier.height(20.dp))
            CircularProgressIndicator(color = Orange)
        }
    }
}

@Composable
private fun Logo() {
    Text("SPEED RUN", color = Orange, fontSize = 36.sp, fontWeight = FontWeight.Black)
    Text("طلباتك... توصل أسرع", color = Color.White, fontSize = 16.sp)
}

@Composable
private fun WelcomeScreen(
    language: String, onLanguage: (String) -> Unit, onRole: (PublicRole) -> Unit
) {
    Column(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF070707), Color(0xFF17100A), Black))
        ).verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(34.dp))
        Logo()
        Spacer(Modifier.height(10.dp))
        Text("توصيل أسرع • تجربة أذكى", color = Muted)
        Spacer(Modifier.height(28.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("العربية", "English", "اردو", "বাংলা").forEach {
                FilterChip(selected = language == it, onClick = { onLanguage(it) }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(28.dp))
        PublicRoleCard("العميل", "اطلب من أفضل المطاعم وتابع طلبك لحظة بلحظة", Icons.Default.Person, PublicRole.CUSTOMER, onRole)
        PublicRoleCard("السائق / المندوب", "استقبل الطلبات وأدر رحلاتك وأرباحك", Icons.Default.DirectionsCar, PublicRole.DRIVER, onRole)
        PublicRoleCard("المطعم", "أدر قائمتك واستقبل الطلبات ونظّم مبيعاتك", Icons.Default.Store, PublicRole.RESTAURANT, onRole)
        Spacer(Modifier.height(22.dp))
        Text(
            "حسابات المالك والمدير والمشرف لا تظهر للعامة ويتم منحها من الإدارة فقط.",
            color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun PublicRoleCard(
    title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
    role: PublicRole, onRole: (PublicRole) -> Unit
) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 7.dp).clickable { onRole(role) },
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1C))
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(Orange),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White) }
            Spacer(Modifier.width(15.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Orange)
        }
    }
}

private enum class AuthMode { EMAIL, PHONE }

@Composable
private fun AuthScreen(
    selected: PublicRole, language: String, onBack: () -> Unit,
    onSuccess: (Role, Boolean) -> Unit
) {
    val activity = LocalContext.current as? Activity
    var mode by remember { mutableStateOf(AuthMode.PHONE) }
    var create by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }

    fun finish(uid: String) {
        if (create && selected != PublicRole.CUSTOMER) {
            val requested = selected.name
            db.collection("applications").document(uid).set(
                mapOf(
                    "uid" to uid, "requestedRole" to requested, "status" to "PENDING",
                    "email" to (auth.currentUser?.email ?: ""),
                    "phone" to (auth.currentUser?.phoneNumber ?: ""),
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).addOnCompleteListener {
                saveBaseUser(uid, requested)
                onSuccess(Role.CUSTOMER, true)
            }
        } else {
            saveBaseUser(uid, selected.name)
            resolveRole(uid) { role, pending -> onSuccess(role, pending) }
        }
    }

    Column(Modifier.fillMaxSize().background(Black).verticalScroll(rememberScrollState()).padding(20.dp)) {
        TextButton(onClick = onBack) { Text("رجوع", color = Orange) }
        Spacer(Modifier.height(15.dp))
        Logo()
        Spacer(Modifier.height(10.dp))
        Text(
            when (selected) {
                PublicRole.CUSTOMER -> "حساب العميل"
                PublicRole.DRIVER -> "طلب الانضمام كسائق"
                PublicRole.RESTAURANT -> "طلب الانضمام كمطعم"
            },
            fontSize = 23.sp, fontWeight = FontWeight.Bold
        )
        Text(language, color = Muted)
        Spacer(Modifier.height(20.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == AuthMode.PHONE, onClick = { mode = AuthMode.PHONE; message = "" }, label = { Text("رقم الجوال") })
            FilterChip(selected = mode == AuthMode.EMAIL, onClick = { mode = AuthMode.EMAIL; message = "" }, label = { Text("البريد الإلكتروني") })
        }
        Spacer(Modifier.height(18.dp))

        if (mode == AuthMode.EMAIL) {
            Field(email, { email = it }, "البريد الإلكتروني", KeyboardType.Email)
            Spacer(Modifier.height(10.dp))
            Field(password, { password = it }, "كلمة المرور", KeyboardType.Password)
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { create = !create }) {
                Text(if (create) "لديك حساب؟ تسجيل الدخول" else "إنشاء حساب جديد", color = Orange)
            }
            PrimaryButton(if (create) "إنشاء الحساب" else "تسجيل الدخول", busy) {
                if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) {
                    message = "اكتب بريدًا إلكترونيًا صحيحًا"; return@PrimaryButton
                }
                if (password.length < 6) {
                    message = "كلمة المرور يجب أن تكون 6 أحرف على الأقل"; return@PrimaryButton
                }
                busy = true
                val task = if (create)
                    auth.createUserWithEmailAndPassword(email.trim(), password)
                else auth.signInWithEmailAndPassword(email.trim(), password)
                task.addOnCompleteListener { result ->
                    busy = false
                    if (result.isSuccessful) finish(result.result!!.user!!.uid)
                    else message = result.exception?.localizedMessage ?: "تعذر إكمال العملية"
                }
            }
        } else {
            Field(phone, { phone = it }, "الجوال بصيغة دولية +9665XXXXXXXX", KeyboardType.Phone)
            Spacer(Modifier.height(10.dp))
            if (verificationId == null) {
                PrimaryButton("إرسال رمز التحقق", busy) {
                    if (activity == null || !phone.trim().startsWith("+")) {
                        message = "اكتب الرقم بصيغة دولية مثل +9665XXXXXXXX"; return@PrimaryButton
                    }
                    busy = true
                    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                            auth.signInWithCredential(credential).addOnCompleteListener { result ->
                                busy = false
                                if (result.isSuccessful) finish(result.result!!.user!!.uid)
                                else message = result.exception?.localizedMessage ?: "تعذر الدخول"
                            }
                        }
                        override fun onVerificationFailed(e: com.google.firebase.FirebaseException) {
                            busy = false
                            message = e.localizedMessage ?: "فشل إرسال رمز التحقق"
                        }
                        override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                            verificationId = id; busy = false; message = "تم إرسال رمز التحقق"
                        }
                    }
                    PhoneAuthProvider.verifyPhoneNumber(
                        PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone.trim())
                            .setTimeout(60L, TimeUnit.SECONDS).setActivity(activity).setCallbacks(callbacks).build()
                    )
                }
            } else {
                Field(otp, { otp = it }, "رمز التحقق", KeyboardType.Number)
                Spacer(Modifier.height(10.dp))
                PrimaryButton("تأكيد وتسجيل الدخول", busy) {
                    busy = true
                    auth.signInWithCredential(
                        PhoneAuthProvider.getCredential(verificationId!!, otp.trim())
                    ).addOnCompleteListener { result ->
                        busy = false
                        if (result.isSuccessful) finish(result.result!!.user!!.uid)
                        else message = result.exception?.localizedMessage ?: "رمز التحقق غير صحيح"
                    }
                }
            }
        }
        if (message.isNotBlank()) Text(message, color = if (message.contains("تم")) Green else Red, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun Field(value: String, onValue: (String) -> Unit, label: String, type: KeyboardType) {
    OutlinedTextField(
        value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(),
        label = { Text(label) }, keyboardOptions = KeyboardOptions(keyboardType = type),
        singleLine = true, shape = RoundedCornerShape(14.dp)
    )
}

@Composable
private fun PrimaryButton(text: String, busy: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = !busy,
        modifier = Modifier.fillMaxWidth().height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Orange),
        shape = RoundedCornerShape(16.dp)
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White)
        else Text(text, fontWeight = FontWeight.Bold)
    }
}

private fun saveBaseUser(uid: String, requestedRole: String) {
    val u = auth.currentUser ?: return
    db.collection("users").document(uid).set(
        mapOf(
            "uid" to uid, "email" to (u.email ?: ""), "phone" to (u.phoneNumber ?: ""),
            "requestedRole" to requestedRole, "updatedAt" to FieldValue.serverTimestamp()
        ), com.google.firebase.firestore.SetOptions.merge()
    )
    FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
        db.collection("users").document(uid).set(mapOf("fcmToken" to token), com.google.firebase.firestore.SetOptions.merge())
    }
}

private fun resolveRole(uid: String, done: (Role, Boolean) -> Unit) {
    db.collection("roles").document(uid).get().addOnSuccessListener { snap ->
        val name = snap.getString("role")
        if (name != null) {
            val role = runCatching { Role.valueOf(name) }.getOrDefault(Role.CUSTOMER)
            done(role, false)
        } else {
            db.collection("applications").document(uid).get().addOnSuccessListener { app ->
                done(Role.CUSTOMER, app.exists() && app.getString("status") == "PENDING")
            }.addOnFailureListener { done(Role.CUSTOMER, false) }
        }
    }.addOnFailureListener { done(Role.CUSTOMER, false) }
}

@Composable
private fun PendingScreen(onLogout: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Black).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(82.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.HourglassTop, null, tint = Color.White, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(20.dp))
        Text("طلبك قيد المراجعة", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("سيتم تفعيل حسابك بعد اعتماد الإدارة.", color = Muted, textAlign = TextAlign.Center, modifier = Modifier.padding(12.dp))
        OutlinedButton(onClick = onLogout) { Text("تسجيل الخروج") }
    }
}

@Composable
private fun CustomerApp(language: String, logout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var selectedRestaurant by remember { mutableStateOf<Restaurant?>(null) }
    var chatOrder by remember { mutableStateOf<Order?>(null) }
    if (selectedRestaurant != null) {
        RestaurantDetails(selectedRestaurant!!, onBack = { selectedRestaurant = null }) { selectedRestaurant = null }
        return
    }
    if (chatOrder != null) {
        ChatScreen(chatOrder!!, { chatOrder = null })
        return
    }
    Scaffold(
        containerColor = Black,
        bottomBar = { BottomBar(tab) { tab = it } }
    ) { p ->
        Column(Modifier.fillMaxSize().padding(p)) {
            when (tab) {
                0 -> CustomerHome(language, logout) { selectedRestaurant = it }
                1 -> OrdersScreen { chatOrder = it }
                2 -> FavoritesScreen()
                else -> ProfileScreen(logout)
            }
        }
    }
}

@Composable
private fun CustomerHome(language: String, logout: () -> Unit, onRestaurant: (Restaurant) -> Unit) {
    var restaurants by remember { mutableStateOf<List<Restaurant>>(emptyList()) }
    LaunchedEffect(Unit) {
        db.collection("restaurants").whereEqualTo("open", true).limit(30).get()
            .addOnSuccessListener { snap ->
                restaurants = snap.documents.map {
                    Restaurant(it.id, it.getString("ownerId") ?: "", it.getString("name") ?: "مطعم",
                        it.getString("category") ?: "مطاعم", it.getString("city") ?: "الرياض",
                        it.getDouble("rating") ?: 0.0, it.getString("eta") ?: "20–35 دقيقة",
                        it.getBoolean("open") ?: true)
                }
            }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("مرحبًا بك", color = Muted)
                    Text("ماذا تشتهي اليوم؟", fontSize = 25.sp, fontWeight = FontWeight.Black)
                }
                IconButton(onClick = logout) { Icon(Icons.Default.Logout, "خروج", tint = Muted) }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Orange)) {
                Column(Modifier.padding(20.dp)) {
                    Text("عروض Speed Run", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black)
                    Text("خصومات وتوصيل سريع من مطاعم مختارة", color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Orange)) {
                        Text("استكشف العروض")
                    }
                }
            }
        }
        item {
            Text("التصنيفات", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("الكل", "برجر", "بيتزا", "مشويات", "حلويات", "مأكولات عربية").forEach {
                    AssistChip(onClick = {}, label = { Text(it) }, leadingIcon = { Icon(Icons.Default.Restaurant, null) })
                }
            }
        }
        item { Text("المطاعم القريبة", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (restaurants.isEmpty()) item {
            EmptyCard("سيتم عرض المطاعم المعتمدة هنا.")
        } else items(restaurants) { RestaurantCard(it) { onRestaurant(it) } }
    }
}

@Composable
private fun RestaurantCard(r: Restaurant, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Card)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(115.dp).background(Brush.linearGradient(listOf(OrangeDark, Color(0xFF2A170D))))) {
                Text("SPEED RUN", Modifier.align(Alignment.Center), color = Color.White, fontWeight = FontWeight.Black, fontSize = 28.sp)
            }
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.name, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
                    Text("⭐ ${"%.1f".format(r.rating)}", color = Orange)
                }
                Text("${r.category} • ${r.eta}", color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun RestaurantDetails(r: Restaurant, onBack: () -> Unit, done: () -> Unit) {
    var address by remember { mutableStateOf("") }
    var creating by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(Black)) {
        TopBar(r.name, onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Orange)) {
                Column(Modifier.padding(22.dp)) {
                    Text(r.name, fontSize = 26.sp, fontWeight = FontWeight.Black)
                    Text("${r.category} • ⭐ ${r.rating} • ${r.eta}", color = Color.White)
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("القائمة", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            MenuItemCard("وجبة برجر سبيد", "برجر + بطاطس + مشروب", 28.0)
            MenuItemCard("وجبة دجاج", "دجاج + بطاطس + مشروب", 24.0)
            MenuItemCard("بطاطس كبيرة", "بطاطس مقرمشة", 12.0)
            Spacer(Modifier.height(16.dp))
            Text("عنوان التوصيل", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Field(address, { address = it }, "اكتب عنوانك", KeyboardType.Text)
            Spacer(Modifier.height(12.dp))
            PrimaryButton("إتمام الطلب • 64 ريال", creating) {
                if (address.isBlank()) return@PrimaryButton
                creating = true
                val ref = db.collection("orders").document()
                ref.set(
                    mapOf(
                        "customerId" to auth.currentUser!!.uid, "restaurantId" to r.id, "restaurantOwnerId" to r.ownerId,
                        "restaurantName" to r.name, "status" to "NEW", "total" to 64.0,
                        "address" to address.trim(), "createdAt" to FieldValue.serverTimestamp()
                    )
                ).addOnCompleteListener { creating = false; done() }
            }
        }
    }
}

@Composable private fun MenuItemCard(name: String, desc: String, price: Double) {
    Card(Modifier.fillMaxWidth().padding(vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Orange), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Fastfood, null, tint = Color.White)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); Text(desc, color = Muted, fontSize = 12.sp) }
            Text("$price ريال", color = Orange, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun OrdersScreen(onChat: (Order) -> Unit) {
    var orders by remember { mutableStateOf<List<Order>>(emptyList()) }
    DisposableEffect(Unit) {
        val reg = db.collection("orders").whereEqualTo("customerId", auth.currentUser!!.uid)
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(30)
            .addSnapshotListener { snap, _ ->
                orders = snap?.documents?.map { orderFrom(it) } ?: emptyList()
            }
        onDispose { reg.remove() }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("طلباتي", fontSize = 27.sp, fontWeight = FontWeight.Black) }
        if (orders.isEmpty()) item { EmptyCard("لا توجد طلبات حتى الآن.") }
        items(orders) { o ->
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(15.dp)) {
                    Row { Text(o.restaurantName, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); StatusPill(o.status) }
                    Text("${o.total} ريال • ${o.address}", color = Muted, fontSize = 12.sp)
                    if (o.driverId.isNotBlank()) {
                        TextButton(onClick = { onChat(o) }) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(5.dp)); Text("التواصل مع السائق") }
                    }
                }
            }
        }
    }
}

@Composable private fun FavoritesScreen() { EmptyCard("المفضلة ستظهر هنا عند إضافة مطاعم إليها.") }
@Composable private fun ProfileScreen(logout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("حسابي", fontSize = 27.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(20.dp))
        Box(Modifier.size(90.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(12.dp))
        Text(auth.currentUser?.email ?: auth.currentUser?.phoneNumber ?: "عميل", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(25.dp))
        OutlinedButton(onClick = logout) { Icon(Icons.Default.Logout, null); Spacer(Modifier.width(8.dp)); Text("تسجيل الخروج") }
    }
}

@Composable
private fun DriverApp(logout: () -> Unit) {
    var online by remember { mutableStateOf(false) }
    var orders by remember { mutableStateOf<List<Order>>(emptyList()) }
    DisposableEffect(Unit) {
        val reg = db.collection("orders").whereEqualTo("status", "NEW").limit(30)
            .addSnapshotListener { snap, _ -> orders = snap?.documents?.map { orderFrom(it) } ?: emptyList() }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize().background(Black)) {
        TopBar("تطبيق السائق / المندوب", logout)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("حالتك الآن", color = Muted)
                            Text(if (online) "متاح لاستقبال الطلبات" else "غير متصل", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        }
                        Switch(checked = online, onCheckedChange = { online = it })
                    }
                }
            }
            item { Text("طلبات قريبة", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            if (orders.isEmpty()) item { EmptyCard("لا توجد طلبات جديدة حاليًا.") }
            items(orders) { o ->
                OrderActionCard(o, "قبول الطلب") {
                    db.collection("orders").document(o.id).update(
                        mapOf("driverId" to auth.currentUser!!.uid, "status" to "ACCEPTED", "acceptedAt" to FieldValue.serverTimestamp())
                    )
                }
            }
        }
    }
}

@Composable
private fun RestaurantApp(logout: () -> Unit) {
    var open by remember { mutableStateOf(true) }
    var orders by remember { mutableStateOf<List<Order>>(emptyList()) }
    DisposableEffect(Unit) {
        val reg = db.collection("orders").whereEqualTo("restaurantOwnerId", auth.currentUser!!.uid)
            .limit(50).addSnapshotListener { snap, _ -> orders = snap?.documents?.map { orderFrom(it) } ?: emptyList() }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize().background(Black)) {
        TopBar("بوابة المطعم", logout)
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("حالة المطعم", color = Muted); Text(if (open) "مفتوح لاستقبال الطلبات" else "مغلق", fontWeight = FontWeight.Bold) }
                        Switch(checked = open, onCheckedChange = { open = it })
                    }
                }
            }
            item { Text("الطلبات الواردة", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            if (orders.isEmpty()) item { EmptyCard("لا توجد طلبات مرتبطة بهذا المطعم.") }
            items(orders) { o ->
                OrderActionCard(o, if (o.status == "NEW") "قبول الطلب" else "تحديث الحالة") {
                    val next = if (o.status == "NEW") "PREPARING" else "READY"
                    db.collection("orders").document(o.id).update("status", next)
                }
            }
        }
    }
}

@Composable
private fun StaffApp(title: String, owner: Boolean, logout: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var detail by remember { mutableStateOf<String?>(null) }
    if (detail != null) {
        StaffDetail(detail!!, owner) { detail = null }
        return
    }
    Scaffold(containerColor = Black, bottomBar = {
        NavigationBar(containerColor = Color(0xFF141414)) {
            listOf("الرئيسية", "المستخدمون", "الطلبات", "الإعدادات").forEachIndexed { i, label ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {
                    Icon(listOf(Icons.Default.Dashboard, Icons.Default.People, Icons.Default.ListAlt, Icons.Default.Settings)[i], null)
                }, label = { Text(label) })
            }
        }
    }) { p ->
        Column(Modifier.fillMaxSize().padding(p)) {
            TopBar("لوحة $title", logout)
            when (tab) {
                0 -> StaffDashboard(owner) { detail = it }
                1 -> StaffUsers(owner)
                2 -> StaffOrders()
                else -> StaffSettings()
            }
        }
    }
}

@Composable private fun StaffDashboard(owner: Boolean, onDetail: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("نظرة عامة", fontSize = 26.sp, fontWeight = FontWeight.Black) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("الطلبات", "—", Icons.Default.ReceiptLong, Modifier.weight(1f))
            StatCard("الإيرادات", "—", Icons.Default.Payments, Modifier.weight(1f))
        }}
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("المستخدمون", "—", Icons.Default.People, Modifier.weight(1f))
            StatCard("السائقون", "—", Icons.Default.DirectionsCar, Modifier.weight(1f))
        }}
        item { SectionCard("إدارة المنصة", listOf("إدارة المستخدمين", "إدارة السائقين", "إدارة المطاعم", "مراقبة الطلبات", "التقارير والإحصائيات", "الكوبونات والعروض", if (owner) "الصلاحيات وسجل العمليات" else "طلبات الانضمام"), onDetail) }
    }
}
@Composable private fun StaffUsers(owner: Boolean) {
    var apps by remember { mutableStateOf<List<com.google.firebase.firestore.DocumentSnapshot>>(emptyList()) }
    DisposableEffect(Unit) {
        val reg = db.collection("applications").whereEqualTo("status", "PENDING").limit(50)
            .addSnapshotListener { snap, _ -> apps = snap?.documents ?: emptyList() }
        onDispose { reg.remove() }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("طلبات الانضمام", fontSize = 25.sp, fontWeight = FontWeight.Black) }
        if (apps.isEmpty()) item { EmptyCard("لا توجد طلبات معلقة.") }
        items(apps) { app ->
            val requested = app.getString("requestedRole") ?: ""
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card)) {
                Column(Modifier.padding(14.dp)) {
                    Text(if (requested == "DRIVER") "طلب سائق" else "طلب مطعم", fontWeight = FontWeight.Bold)
                    Text(app.getString("email") ?: app.getString("phone") ?: app.id, color = Muted, fontSize = 12.sp)
                    if (owner) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                db.collection("roles").document(app.id).set(mapOf("role" to requested))
                                db.collection("applications").document(app.id).update("status", "APPROVED")
                            }, colors = ButtonDefaults.buttonColors(containerColor = Green), modifier = Modifier.weight(1f)) { Text("اعتماد") }
                            OutlinedButton(onClick = { db.collection("applications").document(app.id).update("status", "REJECTED") }, modifier = Modifier.weight(1f)) { Text("رفض") }
                        }
                    } else {
                        Text("الموافقة النهائية متاحة للمالك فقط.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
@Composable private fun StaffOrders() { EmptyCard("هنا ستظهر الطلبات الحية مع فلاتر الحالة والسائق والمطعم.") }
@Composable private fun StaffSettings() { EmptyCard("إعدادات المنصة والصلاحيات وسجل العمليات ستكون هنا.") }

@Composable private fun SectionCard(title: String, items: List<String>, onItem: (String) -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            items.forEach {
                Row(Modifier.fillMaxWidth().clickable { onItem(it) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ChevronRight, null, tint = Orange)
                    Spacer(Modifier.width(8.dp)); Text(it)
                }
            }
        }
    }
}

@Composable private fun StaffDetail(title: String, owner: Boolean, back: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Black)) {
        TopBar(title, back)
        when (title) {
            "إدارة المستخدمين" -> StaffUsers(owner)
            "إدارة السائقين" -> EmptyCard("قائمة السائقين، حالتهم، تقييماتهم وأرباحهم ستظهر هنا.")
            "إدارة المطاعم" -> EmptyCard("المطاعم المعتمدة، حالة الفتح، التقييمات والقائمة ستظهر هنا.")
            "مراقبة الطلبات" -> StaffOrders()
            "التقارير والإحصائيات" -> EmptyCard("التقارير اليومية والشهرية والإيرادات والعمولات ستظهر هنا.")
            "الكوبونات والعروض" -> EmptyCard("إنشاء وإدارة العروض والكوبونات وربطها بالطلبات.")
            "الصلاحيات وسجل العمليات" -> EmptyCard("إدارة الصلاحيات وسجل العمليات الخاص بالمنصة.")
            else -> StaffUsers(owner)
        }
    }
}

@Composable private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Orange); Spacer(Modifier.height(8.dp)); Text(title, color = Muted, fontSize = 12.sp); Text(value, color = Orange, fontSize = 23.sp, fontWeight = FontWeight.Black) }
    }
}
@Composable private fun OrderActionCard(o: Order, action: String, onAction: () -> Unit) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row { Text(o.restaurantName.ifBlank { "طلب" }, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); StatusPill(o.status) }
            Text("${o.total} ريال • ${o.address}", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = Orange), modifier = Modifier.fillMaxWidth()) { Text(action) }
        }
    }
}
@Composable private fun StatusPill(status: String) {
    Surface(shape = RoundedCornerShape(50), color = Orange.copy(alpha = .16f)) { Text(statusLabel(status), color = Orange, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)) }
}
private fun statusLabel(s: String) = when(s) {
    "NEW" -> "جديد"; "ACCEPTED" -> "تم قبول الطلب"; "PREPARING" -> "قيد التجهيز"; "READY" -> "جاهز للاستلام"; "PICKED_UP" -> "مع السائق"; "DELIVERED" -> "تم التسليم"; else -> s
}

@Composable private fun ChatScreen(order: Order, back: () -> Unit) {
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    val room = "order_${order.id}"
    DisposableEffect(order.id) {
        val reg = db.collection("chats").document(room).collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING).addSnapshotListener { snap, _ ->
                messages = snap?.documents?.map { ChatMessage(it.id, it.getString("senderId") ?: "", it.getString("text") ?: "", it.getLong("createdAt") ?: 0L) } ?: emptyList()
            }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize().background(Black)) {
        TopBar("التواصل بخصوص الطلب", back)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(messages) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.senderId == auth.currentUser!!.uid) Arrangement.End else Arrangement.Start) {
                    Surface(shape = RoundedCornerShape(15.dp), color = if (m.senderId == auth.currentUser!!.uid) Orange else Card) {
                        Text(m.text, Modifier.padding(10.dp))
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") }, singleLine = true)
            IconButton(onClick = {
                val v = text.trim(); if (v.isNotEmpty()) {
                    db.collection("chats").document(room).collection("messages").add(
                        mapOf("senderId" to auth.currentUser!!.uid, "text" to v, "createdAt" to System.currentTimeMillis())
                    ); text = ""
                }
            }) { Icon(Icons.Default.Send, null, tint = Orange) }
        }
    }
}

@Composable private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF141414)) {
        listOf("الرئيسية", "طلباتي", "المفضلة", "حسابي").forEachIndexed { i, label ->
            NavigationBarItem(selected = selected == i, onClick = { onSelect(i) },
                icon = { Icon(listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Favorite, Icons.Default.Person)[i], null) },
                label = { Text(label) })
        }
    }
}
@Composable private fun TopBar(title: String, back: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF111111)).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = back) { Icon(Icons.Default.ArrowBack, "رجوع", tint = Orange) }
        Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        Text("SR", color = Orange, fontWeight = FontWeight.Black)
    }
}
@Composable private fun EmptyCard(text: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Card), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Info, null, tint = Orange, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(8.dp)); Text(text, color = Muted, textAlign = TextAlign.Center)
        }
    }
}
private fun orderFrom(d: com.google.firebase.firestore.DocumentSnapshot) = Order(
    d.id, d.getString("customerId") ?: "", d.getString("driverId") ?: "",
    d.getString("restaurantId") ?: "", d.getString("restaurantName") ?: "",
    d.getString("status") ?: "NEW", d.getDouble("total") ?: 0.0,
    d.getString("address") ?: "", d.getTimestamp("createdAt")?.toDate()?.time ?: 0L
)
