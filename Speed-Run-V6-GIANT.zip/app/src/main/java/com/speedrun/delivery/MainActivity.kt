package com.speedrun.delivery

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseException
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

private val Orange = Color(0xFFFF6A00)
private val Orange2 = Color(0xFFFF8A00)
private val Ink = Color(0xFF0B0B0C)
private val CardDark = Color(0xFF171719)
private val Muted = Color(0xFF9FA0A6)
private val Green = Color(0xFF2DBE72)
private val Red = Color(0xFFE85D5D)
private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER, OWNER }
enum class EntryRole { CUSTOMER, DRIVER, RESTAURANT }
enum class AuthMode { EMAIL, PHONE }

data class Restaurant(val id: String, val name: String, val category: String, val rating: Double, val eta: String, val price: String)
data class MenuItem(val name: String, val description: String, val price: Int)
data class Order(val id: String, val restaurant: String, val total: Int, val status: String)

private val demoRestaurants = listOf(
    Restaurant("r1", "برجر تايم", "برجر", 4.8, "20-30 دقيقة", "$$"),
    Restaurant("r2", "بيتزا الخليج", "بيتزا", 4.7, "25-35 دقيقة", "$$"),
    Restaurant("r3", "مشويات النخبة", "مشويات", 4.6, "30-40 دقيقة", "$$$"),
    Restaurant("r4", "مذاق عربي", "عربي", 4.5, "20-30 دقيقة", "$$")
)

private val demoMenu = listOf(
    MenuItem("وجبة البرجر الكلاسيك", "برجر لحم، جبنة، بطاطس", 28),
    MenuItem("وجبة تشكن كريسبي", "دجاج مقرمش، صوص خاص، بطاطس", 24),
    MenuItem("بطاطس كبيرة", "بطاطس مع صوص", 12),
    MenuItem("كولا 330 مل", "مشروب بارد", 8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedRunApp() }
    }
}

@Composable
fun SpeedRunApp() {
    var language by remember { mutableStateOf("العربية") }
    var entryRole by remember { mutableStateOf<EntryRole?>(null) }
    var loggedRole by remember { mutableStateOf<Role?>(null) }
    var pendingTitle by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(auth.currentUser != null) }

    LaunchedEffect(Unit) {
        val user = auth.currentUser
        if (user == null) {
            loading = false
        } else {
            resolveRole(user.uid) { role ->
                loggedRole = role
                loading = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Ink, surface = CardDark)) {
        Surface(Modifier.fillMaxSize(), color = Ink) {
            when {
                loading -> LoadingScreen()
                pendingTitle != null -> PendingScreen(pendingTitle!!, onBack = { pendingTitle = null; entryRole = null }, onLogout = { auth.signOut(); pendingTitle = null; entryRole = null })
                loggedRole != null -> RoleRouter(loggedRole!!, language) { auth.signOut(); loggedRole = null; entryRole = null }
                entryRole != null -> AuthScreen(
                    role = entryRole!!,
                    language = language,
                    onBack = { entryRole = null },
                    onCompleted = { result ->
                        when (result) {
                            is AuthResult.LoggedIn -> loggedRole = result.role
                            is AuthResult.Pending -> pendingTitle = result.title
                        }
                    }
                )
                else -> LandingScreen(language, onLanguage = { language = it }, onRole = { entryRole = it })
            }
        }
    }
}

private sealed class AuthResult {
    data class LoggedIn(val role: Role) : AuthResult()
    data class Pending(val title: String) : AuthResult()
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            LogoMark()
            Spacer(Modifier.height(18.dp))
            CircularProgressIndicator(color = Orange)
            Spacer(Modifier.height(12.dp))
            Text("جاري تجهيز التطبيق...", color = Muted)
        }
    }
}

@Composable
private fun LogoMark() {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("SPEED RUN", color = Orange, fontSize = 42.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        Text("طلباتك... توصل أسرع", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun LandingScreen(language: String, onLanguage: (String) -> Unit, onRole: (EntryRole) -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(20.dp))
        LogoMark()
        Spacer(Modifier.height(30.dp))
        Text("اختر اللغة", color = Color.White, fontSize = 15.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("العربية", "English", "اردو", "বাংলা").forEach { lang ->
                FilterChip(
                    selected = language == lang,
                    onClick = { onLanguage(lang) },
                    label = { Text(lang, fontSize = 11.sp) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
        Spacer(Modifier.height(28.dp))
        Text("ابدأ باستخدام Speed Run", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("اختر نوع حسابك. الحسابات الإدارية لا تظهر هنا.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        EntryCard("العميل", "اطلب طعامك، ادفع وتابع طلبك لحظة بلحظة", Icons.Default.Person, { onRole(EntryRole.CUSTOMER) })
        EntryCard("السائق / المندوب", "استقبل الطلبات، وصلها وشاهد أرباحك", Icons.Default.DirectionsCar, { onRole(EntryRole.DRIVER) })
        EntryCard("المطعم", "أدر المنيو والطلبات والعروض", Icons.Default.Storefront, { onRole(EntryRole.RESTAURANT) })
        Spacer(Modifier.height(14.dp))
        SmallInfoCard(Icons.Default.VerifiedUser, "الحسابات الإدارية", "المالك والمدير والمشرف تُمنح داخليًا من لوحة الإدارة فقط.")
        Spacer(Modifier.height(30.dp))
    }
}

@Composable
private fun EntryCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CardDark)
    ) {
        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(56.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Orange)
        }
    }
}

@Composable
private fun SmallInfoCard(icon: ImageVector, title: String, text: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF111214)), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, null, tint = Orange, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.Bold)
                Text(text, color = Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun AuthScreen(role: EntryRole, language: String, onBack: () -> Unit, onCompleted: (AuthResult) -> Unit) {
    val context = LocalContext.current
    val activity = context as? Activity
    var mode by remember { mutableStateOf(AuthMode.PHONE) }
    var createAccount by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    fun complete(uid: String) {
        val requested = when (role) {
            EntryRole.CUSTOMER -> Role.CUSTOMER.name
            EntryRole.DRIVER -> Role.DRIVER.name
            EntryRole.RESTAURANT -> Role.RESTAURANT.name
        }
        saveUser(uid, requested) {
            resolveRole(uid) { existing ->
                if (existing != null) {
                    onCompleted(AuthResult.LoggedIn(existing))
                } else if (role == EntryRole.CUSTOMER) {
                    ensureCustomerRole(uid) { onCompleted(AuthResult.LoggedIn(Role.CUSTOMER)) }
                } else {
                    createApplication(uid, requested) { onCompleted(AuthResult.Pending(if (role == EntryRole.DRIVER) "طلب انضمام السائق" else "طلب انضمام المطعم")) }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp)) {
        TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(4.dp)); Text("رجوع") }
        Spacer(Modifier.height(8.dp))
        LogoMark()
        Spacer(Modifier.height(20.dp))
        Text(roleTitle(role), color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(if (role == EntryRole.CUSTOMER) "سجّل دخولك وابدأ الطلب" else "سجّل طلبك وسيتم اعتماد الحساب بعد المراجعة", color = Muted)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == AuthMode.PHONE, onClick = { mode = AuthMode.PHONE; message = null }, label = { Text("الجوال") }, modifier = Modifier.weight(1f))
            FilterChip(selected = mode == AuthMode.EMAIL, onClick = { mode = AuthMode.EMAIL; message = null }, label = { Text("البريد") }, modifier = Modifier.weight(1f))
        }
        Spacer(Modifier.height(14.dp))
        if (mode == AuthMode.PHONE) {
            OutlinedTextField(
                value = phone, onValueChange = { phone = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("رقم الجوال الدولي") }, placeholder = { Text("+9665XXXXXXXX") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            Spacer(Modifier.height(10.dp))
            if (verificationId == null) {
                PrimaryButton(if (busy) "جاري إرسال الرمز..." else "إرسال رمز التحقق", busy) {
                    if (activity == null || !phone.trim().startsWith("+")) {
                        message = "اكتب رقم الجوال بصيغة دولية مثل +9665XXXXXXXX"
                    } else {
                        busy = true
                        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                auth.signInWithCredential(credential).addOnCompleteListener { task ->
                                    busy = false
                                    if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid)
                                    else message = task.exception?.localizedMessage ?: "تعذر تسجيل الدخول بالجوال"
                                }
                            }
                            override fun onVerificationFailed(e: FirebaseException) {
                                busy = false
                                message = e.localizedMessage ?: "فشل إرسال رمز التحقق. تأكد من تفعيل Phone في Firebase."
                            }
                            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                                verificationId = id
                                busy = false
                                message = "تم إرسال رمز التحقق"
                            }
                        }
                        val options = PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone.trim()).setTimeout(60L, TimeUnit.SECONDS).setActivity(activity).setCallbacks(callbacks).build()
                        PhoneAuthProvider.verifyPhoneNumber(options)
                    }
                }
            } else {
                OutlinedTextField(value = otp, onValueChange = { otp = it }, modifier = Modifier.fillMaxWidth(), label = { Text("رمز التحقق") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Spacer(Modifier.height(10.dp))
                PrimaryButton("تأكيد الرمز", busy) {
                    val id = verificationId ?: return@PrimaryButton
                    busy = true
                    auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp.trim())).addOnCompleteListener { task ->
                        busy = false
                        if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid)
                        else message = task.exception?.localizedMessage ?: "رمز التحقق غير صحيح"
                    }
                }
                TextButton(onClick = { verificationId = null; otp = "" }) { Text("تغيير الرقم") }
            }
        } else {
            OutlinedTextField(value = email, onValueChange = { email = it }, modifier = Modifier.fillMaxWidth(), label = { Text("البريد الإلكتروني") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = password, onValueChange = { password = it }, modifier = Modifier.fillMaxWidth(), label = { Text("كلمة المرور") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            Spacer(Modifier.height(6.dp))
            TextButton(onClick = { createAccount = !createAccount }) { Text(if (createAccount) "لديك حساب؟ تسجيل الدخول" else "إنشاء حساب جديد") }
            PrimaryButton(if (createAccount) "إنشاء الحساب" else "تسجيل الدخول", busy) {
                if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) message = "اكتب بريدًا صحيحًا"
                else if (password.length < 6) message = "كلمة المرور 6 أحرف على الأقل"
                else {
                    busy = true
                    val task = if (createAccount) auth.createUserWithEmailAndPassword(email.trim(), password) else auth.signInWithEmailAndPassword(email.trim(), password)
                    task.addOnCompleteListener { result ->
                        busy = false
                        if (result.isSuccessful && result.result?.user != null) complete(result.result!!.user!!.uid)
                        else message = result.exception?.localizedMessage ?: "تعذر إكمال العملية"
                    }
                }
            }
        }
        message?.let { Text(it, color = if (it.startsWith("تم")) Green else Red, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(18.dp))
        SmallInfoCard(Icons.Default.Lock, "الخصوصية", "لا يتم منح صلاحيات السائق أو المطعم إلا بعد اعتماد الإدارة.")
        Spacer(Modifier.height(18.dp))
        Text("اللغة: $language", color = Muted, fontSize = 11.sp)
    }
}

@Composable
private fun PrimaryButton(text: String, busy: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(15.dp)) {
        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White) else Text(text, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun PendingScreen(title: String, onBack: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(Icons.Default.PendingActions, null, tint = Orange, modifier = Modifier.size(72.dp))
        Spacer(Modifier.height(18.dp))
        Text(title, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("تم استلام طلبك. سيظهر حسابك بعد مراجعة الإدارة واعتماده.", color = Muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        Spacer(Modifier.height(22.dp))
        PrimaryButton("تسجيل الخروج", false, onLogout)
        TextButton(onClick = onBack) { Text("رجوع") }
    }
}

@Composable
private fun RoleRouter(role: Role, language: String, logout: () -> Unit) {
    when (role) {
        Role.CUSTOMER -> CustomerApp(logout)
        Role.DRIVER -> DriverApp(logout)
        Role.RESTAURANT -> RestaurantApp(logout)
        Role.SUPERVISOR -> AdminApp("المشرف", logout)
        Role.MANAGER -> AdminApp("المدير", logout)
        Role.OWNER -> AdminApp("المالك الرئيسي", logout)
    }
}

@Composable
private fun AppTopBar(title: String, subtitle: String, onLogout: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("SPEED RUN", color = Orange, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "خروج", tint = Color.White) }
    }
}

@Composable
private fun CustomerApp(logout: () -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var selectedRestaurant by remember { mutableStateOf<Restaurant?>(null) }
    var cartCount by remember { mutableStateOf(0) }
    var chatOpen by remember { mutableStateOf(false) }
    if (selectedRestaurant != null) {
        RestaurantDetails(selectedRestaurant!!, cartCount, onAdd = { cartCount++ }, onBack = { selectedRestaurant = null }, onCart = { })
        return
    }
    if (chatOpen) {
        DriverChat(onBack = { chatOpen = false })
        return
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("الرئيسية", "حي الخليج • الرياض", logout)
        when (tab) {
            0 -> Box(Modifier.weight(1f)) { CustomerHomeFeed(onRestaurant = { selectedRestaurant = it }, onChat = { chatOpen = true }) }
            1 -> Box(Modifier.weight(1f)) { OrdersScreen() }
            2 -> Box(Modifier.weight(1f)) { FavoritesScreen() }
            else -> Box(Modifier.weight(1f)) { CustomerProfile(logout) }
        }
        BottomBar(tab, listOf("الرئيسية", "طلباتي", "المفضلة", "حسابي"), listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Favorite, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun CustomerHomeFeed(onRestaurant: (Restaurant) -> Unit, onChat: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Orange), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("عروض اليوم", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                        Text("خصومات وتوصيل أسرع على مطاعم مختارة", color = Color.White)
                        Spacer(Modifier.height(8.dp))
                        AssistChip(onClick = {}, label = { Text("اكتشف العروض") })
                    }
                    Icon(Icons.Default.LocalOffer, null, tint = Color.White, modifier = Modifier.size(50.dp))
                }
            }
        }
        item { CategoryRow() }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("مطاعم قريبة منك", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("الكل", color = Orange)
            }
        }
        items(demoRestaurants) { r -> RestaurantCard(r, onClick = { onRestaurant(r) }) }
        item {
            Spacer(Modifier.height(4.dp))
            OutlinedButton(onClick = onChat, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Chat, null); Spacer(Modifier.width(8.dp)); Text("تواصل مع السائق لطلبك الحالي") }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CategoryRow() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("الكل" to Icons.Default.Restaurant, "برجر" to Icons.Default.Fastfood, "بيتزا" to Icons.Default.LocalPizza, "مشويات" to Icons.Default.Whatshot).forEach { (name, icon) ->
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(Color(0xFF242427)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Orange) }
                Spacer(Modifier.height(4.dp)); Text(name, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun RestaurantCard(r: Restaurant, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(18.dp)) {
        Column {
            Box(Modifier.fillMaxWidth().height(125.dp).background(Brush.horizontalGradient(listOf(Color(0xFF252529), Color(0xFF101011)))), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Restaurant, null, tint = Orange, modifier = Modifier.size(60.dp))
                Box(Modifier.align(Alignment.TopEnd).padding(10.dp).clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(alpha = .65f)).padding(7.dp)) { Text("مفتوح", color = Green, fontSize = 11.sp) }
            }
            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${r.category} • ${r.eta} • ${r.price}", color = Muted, fontSize = 12.sp)
                    Text("⭐ ${r.rating}", color = Orange, fontSize = 12.sp)
                }
                Icon(Icons.Default.ChevronRight, null, tint = Muted)
            }
        }
    }
}

@Composable
private fun RestaurantDetails(r: Restaurant, cartCount: Int, onAdd: () -> Unit, onBack: () -> Unit, onCart: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
            Column(Modifier.weight(1f)) { Text(r.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("⭐ ${r.rating} • ${r.eta}", color = Muted) }
            BadgedIcon(Icons.Default.ShoppingCart, cartCount, onCart)
        }
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { Box(Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Color(0xFF2B2B30), Orange.copy(alpha = .65f)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Restaurant, null, tint = Color.White, modifier = Modifier.size(70.dp)) } }
            item { Text("القائمة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            items(demoMenu) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(62.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF28282B)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Fastfood, null, tint = Orange) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Bold); Text(item.description, color = Muted, fontSize = 11.sp); Text("${item.price} ريال", color = Orange, fontWeight = FontWeight.Bold) }
                        IconButton(onClick = onAdd) { Icon(Icons.Default.AddCircle, null, tint = Orange) }
                    }
                }
            }
        }
        if (cartCount > 0) Button(onClick = onCart, modifier = Modifier.fillMaxWidth().padding(14.dp).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("عرض السلة • $cartCount عنصر") }
    }
}

@Composable
private fun BadgedIcon(icon: ImageVector, count: Int, onClick: () -> Unit) {
    Box {
        IconButton(onClick = onClick) { Icon(icon, null, tint = Color.White) }
        if (count > 0) Box(Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) { Text(count.toString(), color = Color.White, fontSize = 9.sp) }
    }
}

@Composable
private fun OrdersScreen() { SimpleListScreen("طلباتي", listOf("#1250 • برجر تايم • جاري التوصيل", "#1248 • بيتزا الخليج • تم التسليم", "#1242 • مذاق عربي • ملغي"), Icons.Default.ReceiptLong) }
@Composable
private fun FavoritesScreen() { SimpleListScreen("المفضلة", demoRestaurants.map { it.name }, Icons.Default.Favorite) }
@Composable
private fun CustomerProfile(logout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ProfileHeader("أحمد محمد", "حساب عميل موثق") }
        item { ProfileAction("العناوين", Icons.Default.LocationOn) }
        item { ProfileAction("طرق الدفع", Icons.Default.CreditCard) }
        item { ProfileAction("الإشعارات", Icons.Default.Notifications) }
        item { ProfileAction("اللغة", Icons.Default.Language) }
        item { ProfileAction("الدعم", Icons.Default.SupportAgent) }
        item { OutlinedButton(onClick = logout, modifier = Modifier.fillMaxWidth()) { Text("تسجيل الخروج") } }
    }
}

@Composable
private fun DriverApp(logout: () -> Unit) {
    var online by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf(0) }
    var chat by remember { mutableStateOf(false) }
    if (chat) { DriverChat(onBack = { chat = false }); return }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("السائق / المندوب", "الرياض • لوحة العمل", logout)
        when (tab) {
            0 -> LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(20.dp)) {
                        Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text("حالة العمل", color = Muted); Text(if (online) "متاح لاستقبال الطلبات" else "غير متاح", color = if (online) Green else Red, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                            Switch(checked = online, onCheckedChange = { online = it })
                        }
                    }
                }
                item { MetricRow("طلبات اليوم", "5", "320 ريال", Icons.Default.LocalShipping) }
                item { MetricRow("التقييم", "4.9", "98% رضا", Icons.Default.Star) }
                item { Text("طلبات قريبة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                items(listOf("#1251 • برجر تايم • 28 ريال • 1.2 كم", "#1252 • بيتزا الخليج • 42 ريال • 2.0 كم")) { text -> DriverOrderCard(text, onChat = { chat = true }) }
            }
            1 -> Box(Modifier.weight(1f)) { SimpleListScreen("أرباحي", listOf("اليوم: 320 ريال", "هذا الأسبوع: 1,840 ريال", "هذا الشهر: 7,420 ريال"), Icons.Default.Payments) }
            else -> Box(Modifier.weight(1f)) { CustomerProfile(logout) }
        }
        BottomBar(tab, listOf("الرئيسية", "الأرباح", "حسابي"), listOf(Icons.Default.Home, Icons.Default.Payments, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun DriverOrderCard(text: String, onChat: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text(text, color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Orange), modifier = Modifier.weight(1f)) { Text("قبول") }
                OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) { Text("رفض") }
                IconButton(onClick = onChat) { Icon(Icons.Default.Chat, null, tint = Orange) }
            }
        }
    }
}

@Composable
private fun RestaurantApp(logout: () -> Unit) {
    var open by remember { mutableStateOf(true) }
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("بوابة المطعم", "مطعمك • إدارة الطلبات والقائمة", logout)
        when (tab) {
            0 -> LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { MetricRow("طلبات اليوم", "12", "420 ريال", Icons.Default.ReceiptLong) }
                item { MetricRow("التقييم", "4.8", "2.3k تقييم", Icons.Default.Star) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Text(if (open) "المطعم مفتوح" else "المطعم مغلق", color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold); Switch(open, { open = it }) }
                    }
                }
                item { Text("طلبات جديدة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                items(listOf("#1250 • 28 ريال • جديد", "#1249 • 52 ريال • قيد التحضير", "#1248 • 34 ريال • جاهز للاستلام")) { text -> RestaurantOrderCard(text) }
            }
            1 -> Box(Modifier.weight(1f)) { MenuManagement() }
            else -> Box(Modifier.weight(1f)) { CustomerProfile(logout) }
        }
        BottomBar(tab, listOf("الطلبات", "القائمة", "حسابي"), listOf(Icons.Default.ReceiptLong, Icons.Default.MenuBook, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun RestaurantOrderCard(text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(text, color = Color.White, fontWeight = FontWeight.Bold); Text("اضغط لمراجعة الطلب وتغيير حالته", color = Muted, fontSize = 11.sp) }
            Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("فتح") }
        }
    }
}

@Composable
private fun MenuManagement() {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("إدارة القائمة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { PrimaryButton("إضافة صنف جديد", false, {}) }
        items(demoMenu) { item ->
            Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${item.price} ريال", color = Orange) }; IconButton(onClick = {}) { Icon(Icons.Default.Edit, null, tint = Orange) } }
            }
        }
    }
}

@Composable
private fun AdminApp(title: String, logout: () -> Unit) {
    var section by remember { mutableStateOf("dashboard") }
    Column(Modifier.fillMaxSize()) {
        AppTopBar("لوحة $title", "صلاحيات منفصلة • مركز التحكم", logout)
        if (section == "dashboard") {
            Box(Modifier.weight(1f)) { AdminDashboard(title, onSection = { section = it }) }
        } else {
            Box(Modifier.weight(1f)) { AdminSection(section, isOwner = title == "المالك الرئيسي", onBack = { section = "dashboard" }) }
        }
    }
}

@Composable
private fun AdminDashboard(title: String, onSection: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("نظرة عامة", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AdminStat("الطلبات", "1,245", Icons.Default.ReceiptLong); AdminStat("الإيرادات", "28,450", Icons.Default.Payments) } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AdminStat("المستخدمون", "8,642", Icons.Default.People); AdminStat("المطاعم", "320", Icons.Default.Storefront) } }
        item { Text("الإدارة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        val adminItems = listOf(
            "users" to ("المستخدمون" to Icons.Default.People), "drivers" to ("السائقون" to Icons.Default.DirectionsCar),
            "restaurants" to ("المطاعم" to Icons.Default.Storefront), "orders" to ("الطلبات النشطة" to Icons.Default.LocationOn),
            "applications" to ("طلبات الانضمام" to Icons.Default.Assignment), "offers" to ("الكوبونات والعروض" to Icons.Default.LocalOffer),
            "reports" to ("التقارير والإحصائيات" to Icons.Default.BarChart), "permissions" to ("الصلاحيات وسجل العمليات" to Icons.Default.Security)
        )
        items(adminItems) { (key, pair) -> AdminMenuCard(pair.first, pair.second, { onSection(key) }) }
    }
}

@Composable
private fun AdminSection(section: String, isOwner: Boolean, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Text(adminSectionTitle(section), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        when (section) {
            "applications" -> AdminApplications(isOwner)
            "users" -> SimpleListScreen("المستخدمون", listOf("أحمد محمد • عميل", "محمد علي • سائق", "مطعم الخليج • مطعم"), Icons.Default.People)
            "drivers" -> SimpleListScreen("السائقون", listOf("أحمد • متاح • 4.9", "محمد • في طلب • 4.8", "علي • غير متصل • 4.7"), Icons.Default.DirectionsCar)
            "restaurants" -> SimpleListScreen("المطاعم", demoRestaurants.map { "${it.name} • ⭐ ${it.rating}" }, Icons.Default.Storefront)
            "orders" -> SimpleListScreen("الطلبات النشطة", listOf("#1250 • قيد التحضير", "#1251 • مع السائق", "#1252 • قريب من العميل"), Icons.Default.LocationOn)
            "offers" -> SimpleListScreen("العروض والكوبونات", listOf("خصم 20% للمستخدم الجديد", "توصيل مجاني اليوم", "كود SPEED10"), Icons.Default.LocalOffer)
            "reports" -> SimpleListScreen("التقارير", listOf("مبيعات اليوم: 28,450 ريال", "الطلبات: 1,245", "متوسط التقييم: 4.8"), Icons.Default.BarChart)
            else -> SimpleListScreen("الصلاحيات وسجل العمليات", listOf("OWNER • صلاحيات كاملة", "MANAGER • إدارة التشغيل", "SUPERVISOR • متابعة", "سجل: تحديث حالة الطلب #1250"), Icons.Default.Security)
        }
    }
}

@Composable
private fun AdminApplications(isOwner: Boolean) {
    var loading by remember { mutableStateOf(true) }
    var rows by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    fun reload() {
        loading = true
        db.collection("applications").get().addOnSuccessListener { snap ->
            rows = snap.documents.map { doc ->
                val requested = doc.getString("requestedRole") ?: "UNKNOWN"
                doc.id to requested
            }
            loading = false
        }.addOnFailureListener { e ->
            message = e.localizedMessage ?: "تعذر تحميل طلبات الانضمام"
            loading = false
        }
    }
    LaunchedEffect(Unit) { reload() }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        if (loading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) }
        } else if (rows.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد طلبات انضمام حاليًا", color = Muted) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(rows) { (uid, requested) ->
                    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Text(if (requested == "DRIVER") "طلب سائق / مندوب" else "طلب مطعم", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("UID: $uid", color = Muted, fontSize = 10.sp)
                            Spacer(Modifier.height(10.dp))
                            if (isOwner) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        db.collection("roles").document(uid).set(mapOf("role" to requested, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener {
                                            db.collection("users").document(uid).set(mapOf("accountType" to requested, "status" to "ACTIVE"), SetOptions.merge())
                                            db.collection("applications").document(uid).set(mapOf("status" to "APPROVED", "approvedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener { reload() }
                                        }.addOnFailureListener { message = it.localizedMessage ?: "تعذر اعتماد الحساب" }
                                    }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("اعتماد") }
                                    OutlinedButton(onClick = {
                                        db.collection("applications").document(uid).set(mapOf("status" to "REJECTED", "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener { reload() }
                                    }) { Text("رفض") }
                                }
                            } else {
                                Text("الاعتماد النهائي متاح للمالك الرئيسي فقط", color = Orange, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        message?.let { Text(it, color = Red, fontSize = 11.sp) }
    }
}

@Composable
private fun AdminStat(title: String, value: String, icon: ImageVector) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Orange); Text(title, color = Muted, fontSize = 11.sp); Text(value, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black) } }
}

@Composable
private fun AdminMenuCard(title: String, icon: ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } }
}

@Composable
private fun DriverChat(onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Column { Text("محادثة الطلب #1250", color = Color.White, fontWeight = FontWeight.Bold); Text("أحمد • متصل الآن", color = Green, fontSize = 11.sp) } }
        LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { ChatBubble("مرحبًا، أنا في الطريق لاستلام طلبك.", false) }
            item { ChatBubble("تمام، أنا بانتظارك.", true) }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") }, singleLine = true); IconButton(onClick = { text = "" }) { Icon(Icons.Default.Send, null, tint = Orange) } }
    }
}

@Composable
private fun ChatBubble(text: String, mine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) { Surface(color = if (mine) Orange else CardDark, shape = RoundedCornerShape(16.dp)) { Text(text, color = Color.White, modifier = Modifier.padding(12.dp)) } }
}

@Composable
private fun MetricRow(title: String, value: String, extra: String, icon: ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(48.dp).clip(CircleShape).background(Orange.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Orange) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Muted); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; Text(extra, color = Orange, fontWeight = FontWeight.Bold) } }
}

@Composable
private fun ProfileHeader(name: String, subtitle: String) { Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) { Text(name.take(1), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(14.dp)); Column { Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted) } } } }

@Composable
private fun ProfileAction(text: String, icon: ImageVector) { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }

@Composable
private fun SimpleListScreen(title: String, listItems: List<String>, icon: ImageVector) { LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }; items(listItems) { text -> Card(colors = CardDefaults.cardColors(containerColor = CardDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } } } }

@Composable
private fun BottomBar(selected: Int, labels: List<String>, icons: List<ImageVector>, onSelect: (Int) -> Unit) { NavigationBar(containerColor = Color(0xFF111112)) { labels.forEachIndexed { index, label -> NavigationBarItem(selected = selected == index, onClick = { onSelect(index) }, icon = { Icon(icons[index], null) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color(0xFF332116))) } } }

private fun roleTitle(role: EntryRole) = when (role) { EntryRole.CUSTOMER -> "حساب العميل"; EntryRole.DRIVER -> "طلب انضمام سائق / مندوب"; EntryRole.RESTAURANT -> "طلب انضمام مطعم" }
private fun adminSectionTitle(key: String) = mapOf("users" to "المستخدمون", "drivers" to "السائقون", "restaurants" to "المطاعم", "orders" to "الطلبات النشطة", "applications" to "طلبات الانضمام", "offers" to "العروض والكوبونات", "reports" to "التقارير والإحصائيات", "permissions" to "الصلاحيات وسجل العمليات")[key] ?: "الإدارة"

private fun saveUser(uid: String, requestedRole: String, done: () -> Unit) {
    val user = auth.currentUser ?: return done()
    val data = mapOf("uid" to uid, "email" to (user.email ?: ""), "phoneNumber" to (user.phoneNumber ?: ""), "requestedRole" to requestedRole, "updatedAt" to FieldValue.serverTimestamp())
    db.collection("users").document(uid).set(data, SetOptions.merge()).addOnCompleteListener {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token -> db.collection("users").document(uid).set(mapOf("fcmToken" to token), SetOptions.merge()) }
        done()
    }
}

private fun ensureCustomerRole(uid: String, done: () -> Unit) {
    db.collection("users").document(uid).set(mapOf("accountType" to Role.CUSTOMER.name, "status" to "ACTIVE", "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { done() }
}

private fun createApplication(uid: String, requestedRole: String, done: () -> Unit) {
    val data = mapOf("uid" to uid, "requestedRole" to requestedRole, "status" to "PENDING", "createdAt" to FieldValue.serverTimestamp())
    db.collection("applications").document(uid).set(data, SetOptions.merge()).addOnCompleteListener { done() }
}

private fun resolveRole(uid: String, done: (Role?) -> Unit) {
    db.collection("roles").document(uid).get().addOnSuccessListener { snap ->
        val name = snap.getString("role")
        if (!name.isNullOrBlank()) {
            done(runCatching { Role.valueOf(name) }.getOrNull())
        } else {
            db.collection("users").document(uid).get().addOnSuccessListener { userSnap ->
                val accountType = userSnap.getString("accountType")
                done(accountType?.let { runCatching { Role.valueOf(it) }.getOrNull() })
            }.addOnFailureListener { done(null) }
        }
    }.addOnFailureListener {
        db.collection("users").document(uid).get().addOnSuccessListener { userSnap ->
            val accountType = userSnap.getString("accountType")
            done(accountType?.let { runCatching { Role.valueOf(it) }.getOrNull() })
        }.addOnFailureListener { done(null) }
    }
}
