# Speed Run V6

V6 is a redesigned delivery-app foundation built from the V4 Firebase base.

## Product structure
- Public entry: Customer / Driver / Restaurant only.
- Owner / Manager / Supervisor are never selectable from the public entry screen.
- Email/password and Phone OTP authentication are supported.
- Driver and Restaurant accounts submit an application and remain PENDING until staff approval.
- Customer accounts enter the customer app directly.
- Staff dashboards have clickable sections instead of dead cards.
- Customer: restaurant discovery, categories, restaurant details, menu, cart count, orders, favorites, profile, driver chat entry.
- Driver: availability, nearby orders, accept/reject UI, earnings, profile, customer chat.
- Restaurant: open/closed status, orders, menu management, profile.
- Admin: dashboard, users, drivers, restaurants, orders, applications, offers, reports, permissions/audit section.
- Firestore rules include user/application/order/chat isolation and staff permissions.

## Important
Phone OTP still requires Phone provider to be enabled in Firebase Authentication and the project's SHA-1/SHA-256 configuration to be correct for the release/debug build used for testing.

The APK is debug-built for testing. Google Play publishing will require a signed release AAB after the feature tests pass.
