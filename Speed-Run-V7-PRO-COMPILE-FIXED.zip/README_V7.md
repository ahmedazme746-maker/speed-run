# Speed Run V7 — UI & flow rebuild

This version is a real UI rebuild from the V6 source, not a cosmetic patch.

## Fixed
- Landing screen redesigned to match the supplied Speed Run visual direction.
- Arabic / English / Urdu / Bengali now changes the actual UI text and layout direction where appropriate.
- Admin roles are not presented as public login choices.
- Customer, Driver/Courier, and Restaurant are the only public entry roles.
- Driver and Restaurant accounts become active only after owner approval.
- Customer home now has promo hero, search, categories, restaurant cards, cart entry and customer/driver chat entry.
- Driver and Restaurant dashboards have real navigation sections instead of dead-looking cards.
- Admin dashboard reads Firebase collection counts instead of showing fake fixed zero cards.
- Join applications are read from Firestore and can be approved/rejected by the owner.
- Phone OTP and Email/Password flows remain supported.
- Local visual assets are based on the supplied Speed Run reference artwork.

## Build
The included GitHub Actions workflow builds this exact source directly. It does not extract an older V4/V5 ZIP.
