# Speed Run V8 – Product Upgrade

This build keeps the Speed Run V7 foundation and upgrades the real product flow.

## Included in V8
- Creative Speed Run launcher icon.
- Brighter food/category visuals using colorful food imagery and emoji category cues.
- Realistic empty states instead of fake conversations/orders/earnings.
- Driver and restaurant applications require a structured application before activation.
- Phone field normalizes common Saudi formats and is forced to LTR so `+966` is entered correctly.
- Admin sections have real navigation and Back returns to the admin dashboard.
- App sub-screens use Back navigation instead of signing the user out.
- Firestore chat reads actual chat messages only; no seeded fake messages.
- Owner-only approval enforcement for applications in Firestore rules.
- Version 8.0 / versionCode 8.

## Still requiring Firebase console configuration
- Phone Authentication must be enabled in Firebase Authentication.
- Firebase Storage billing/availability must be configured before production document/photo uploads.
- FCM and production Maps/payment integrations still require their project credentials and final configuration.
