package com.speedrun.delivery

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

private val Orange = Color(0xFFFF6A00)
private val Orange2 = Color(0xFFFF8A00)
private val Ink = Color(0xFF07080A)
private val SurfaceDark = Color(0xFF15171B)
private val Surface2 = Color(0xFF20242A)
private val Muted = Color(0xFFAEB4BD)
private val Green = Color(0xFF25D17C)
private val Red = Color(0xFFFF5F5F)
private val Yellow = Color(0xFFFFC107)

private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER, OWNER }
enum class EntryRole { CUSTOMER, DRIVER, RESTAURANT }
enum class AuthMode { PHONE, EMAIL }

data class Restaurant(val id: String, val name: String, val category: String, val rating: Double, val eta: String, val price: String)
data class MenuItem(val name: String, val description: String, val price: Int, val emoji: String)
data class Category(val emoji: String, val title: String)

data class UiStrings(
    val languageName: String,
    val chooseLanguage: String,
    val customer: String,
    val driver: String,
    val restaurant: String,
    val customerSub: String,
    val driverSub: String,
    val restaurantSub: String,
    val adminNote: String,
    val start: String,
    val home: String,
    val orders: String,
    val favorites: String,
    val account: String,
    val search: String,
    val categories: String,
    val featured: String,
    val offers: String,
    val open: String,
    val minutes: String,
    val menu: String,
    val cart: String,
    val add: String,
    val login: String,
    val create: String,
    val phone: String,
    val email: String,
    val password: String,
    val sendOtp: String,
    val verify: String,
    val international: String,
    val back: String,
    val joinPending: String,
    val logout: String,
    val online: String,
    val offline: String,
    val nearbyOrders: String,
    val earnings: String,
    val accept: String,
    val reject: String,
    val chat: String,
    val dashboard: String,
    val users: String,
    val drivers: String,
    val restaurants: String,
    val activeOrders: String,
    val applications: String,
    val offersCoupons: String,
    val reports: String,
    val permissions: String,
    val noApplications: String
)

private val AR = UiStrings("العربية", "اختر اللغة", "العميل", "السائق / المندوب", "المطعم", "اطلب طعامك وتابع طلبك لحظة بلحظة", "استقبل الطلبات ووصلها وشاهد أرباحك", "أدر المنيو والطلبات والعروض", "الحسابات الإدارية تُمنح من لوحة الإدارة فقط", "ابدأ الآن", "الرئيسية", "طلباتي", "المفضلة", "حسابي", "ابحث عن مطعم أو صنف...", "التصنيفات", "المطاعم المميزة", "عروض اليوم", "مفتوح", "دقيقة", "القائمة", "السلة", "إضافة", "تسجيل الدخول", "إنشاء حساب", "الجوال", "البريد الإلكتروني", "كلمة المرور", "إرسال رمز التحقق", "تأكيد الرمز", "اكتب الرقم بصيغة دولية مثل +9665XXXXXXXX", "رجوع", "طلب انضمام", "تسجيل الخروج", "متاح الآن", "غير متاح", "طلبات قريبة", "أرباحي", "قبول", "رفض", "محادثة", "لوحة الإدارة", "المستخدمون", "السائقون", "المطاعم", "الطلبات النشطة", "طلبات الانضمام", "الكوبونات والعروض", "التقارير والإحصائيات", "الصلاحيات والسجل", "لا توجد طلبات انضمام حاليًا")
private val EN = UiStrings("English", "Choose language", "Customer", "Driver / Courier", "Restaurant", "Order food and track it live", "Receive deliveries and track earnings", "Manage your menu, orders and offers", "Admin accounts are granted only from the admin panel", "Get started", "Home", "Orders", "Favorites", "Account", "Search restaurants or dishes...", "Categories", "Featured restaurants", "Today's offers", "Open", "min", "Menu", "Cart", "Add", "Sign in", "Create account", "Phone", "Email", "Password", "Send verification code", "Verify code", "Enter an international number like +9665XXXXXXXX", "Back", "Join request", "Sign out", "Online", "Offline", "Nearby orders", "Earnings", "Accept", "Reject", "Chat", "Admin dashboard", "Users", "Drivers", "Restaurants", "Active orders", "Join requests", "Coupons & offers", "Reports & analytics", "Permissions & audit", "No join requests")
private val UR = UiStrings("اردو", "زبان منتخب کریں", "گاہک", "ڈرائیور / کورئیر", "ریستوران", "کھانا آرڈر کریں اور لائیو ٹریک کریں", "آرڈرز وصول کریں اور آمدنی دیکھیں", "مینو، آرڈرز اور آفرز سنبھالیں", "ایڈمن اکاؤنٹس صرف ایڈمن پینل سے دیے جاتے ہیں", "شروع کریں", "ہوم", "آرڈرز", "پسندیدہ", "اکاؤنٹ", "ریستوران یا کھانا تلاش کریں...", "زمرے", "نمایاں ریستوران", "آج کی آفرز", "کھلا", "منٹ", "مینو", "کارٹ", "شامل کریں", "لاگ اِن", "اکاؤنٹ بنائیں", "فون", "ای میل", "پاس ورڈ", "تصدیقی کوڈ بھیجیں", "کوڈ کی تصدیق", "بین الاقوامی نمبر لکھیں جیسے +9665XXXXXXXX", "واپس", "شمولیت کی درخواست", "لاگ آؤٹ", "آن لائن", "آف لائن", "قریب کے آرڈرز", "کمائی", "قبول", "رد", "چیٹ", "ایڈمن پینل", "صارفین", "ڈرائیور", "ریستوران", "فعال آرڈرز", "شمولیت کی درخواستیں", "کوپن اور آفرز", "رپورٹس اور اعدادوشمار", "اختیارات اور لاگ", "فی الحال کوئی درخواست نہیں")
private val BN = UiStrings("বাংলা", "ভাষা নির্বাচন করুন", "গ্রাহক", "ড্রাইভার / কুরিয়ার", "রেস্টুরেন্ট", "খাবার অর্ডার করুন ও লাইভ ট্র্যাক করুন", "অর্ডার নিন ও আয় দেখুন", "মেনু, অর্ডার ও অফার পরিচালনা করুন", "অ্যাডমিন অ্যাকাউন্ট শুধু অ্যাডমিন প্যানেল থেকে দেওয়া হয়", "শুরু করুন", "হোম", "অর্ডার", "পছন্দের", "অ্যাকাউন্ট", "রেস্টুরেন্ট বা খাবার খুঁজুন...", "ক্যাটাগরি", "জনপ্রিয় রেস্টুরেন্ট", "আজকের অফার", "খোলা", "মিনিট", "মেনু", "কার্ট", "যোগ করুন", "সাইন ইন", "অ্যাকাউন্ট তৈরি", "ফোন", "ইমেইল", "পাসওয়ার্ড", "ভেরিফিকেশন কোড পাঠান", "কোড যাচাই", "আন্তর্জাতিক নম্বর লিখুন যেমন +9665XXXXXXXX", "ফিরে যান", "যোগদানের অনুরোধ", "সাইন আউট", "অনলাইন", "অফলাইন", "কাছের অর্ডার", "আয়", "গ্রহণ", "বাতিল", "চ্যাট", "অ্যাডমিন ড্যাশবোর্ড", "ব্যবহারকারী", "ড্রাইভার", "রেস্টুরেন্ট", "সক্রিয় অর্ডার", "যোগদানের অনুরোধ", "কুপন ও অফার", "রিপোর্ট ও অ্যানালিটিক্স", "অনুমতি ও লগ", "কোনো অনুরোধ নেই")

private fun strings(language: String): UiStrings = when (language) { "English" -> EN; "اردو" -> UR; "বাংলা" -> BN; else -> AR }
private fun isRtl(language: String) = language == "العربية" || language == "اردو"

private val categories = listOf(
    Category("🍕", "بيتزا"), Category("🍔", "برجر"), Category("🍗", "دجاج"),
    Category("🍟", "بطاطس"), Category("🥘", "مشويات"), Category("🍰", "حلويات"),
    Category("🥤", "مشروبات"), Category("🌯", "سندوتشات")
)

private val demoRestaurants = listOf(
    Restaurant("r1", "ماكدونالدز", "برجر", 4.8, "20-30", "$$"),
    Restaurant("r2", "كنتاكي", "دجاج", 4.6, "20-35", "$$"),
    Restaurant("r3", "بيتزا الخليج", "بيتزا", 4.7, "25-35", "$$"),
    Restaurant("r4", "مشويات النخبة", "مشويات", 4.6, "30-40", "$$$"),
    Restaurant("r5", "مذاق عربي", "مشويات", 4.9, "25-40", "$$$")
)

private val demoMenu = listOf(
    MenuItem("برجر سبيد", "برجر لحم، جبنة، بطاطس", 28, "🍔"),
    MenuItem("وجبة تشكن", "دجاج مقرمش وصوص خاص", 24, "🍗"),
    MenuItem("بطاطس كبيرة", "بطاطس مع صوص", 12, "🍟"),
    MenuItem("بيتزا خضار", "جبنة وخضار طازجة", 32, "🍕"),
    MenuItem("كولا 330 مل", "مشروب بارد", 8, "🥤")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SpeedRunApp() }
    }
}

private sealed class SessionState {
    data object Loading : SessionState()
    data object LoggedOut : SessionState()
    data class LoggedIn(val role: Role) : SessionState()
    data class Pending(val role: EntryRole) : SessionState()
    data class NeedsApplication(val role: EntryRole) : SessionState()
}

@Composable
private fun SpeedRunApp() {
    var language by remember { mutableStateOf("العربية") }
    var entryRole by remember { mutableStateOf<EntryRole?>(null) }
    var session by remember { mutableStateOf<SessionState>(SessionState.Loading) }
    val s = strings(language)

    LaunchedEffect(Unit) {
        resolveSession { session = it }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Orange, background = Ink, surface = SurfaceDark)) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isRtl(language)) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            Surface(Modifier.fillMaxSize(), color = Ink) {
                when (val current = session) {
                    SessionState.Loading -> LoadingScreen()
                    SessionState.LoggedOut -> {
                        if (entryRole == null) LandingScreen(language, { language = it }) { entryRole = it }
                        else AuthScreen(entryRole!!, language, { entryRole = null }) { result ->
                            when (result) {
                                is AuthResult.LoggedIn -> { entryRole = null; session = SessionState.LoggedIn(result.role) }
                                is AuthResult.NeedsApplication -> { entryRole = null; session = SessionState.NeedsApplication(result.role) }
                                is AuthResult.Pending -> { entryRole = null; session = SessionState.Pending(result.role) }
                            }
                        }
                    }
                    is SessionState.NeedsApplication -> ApplicationFormScreen(current.role, language) { session = SessionState.Pending(current.role) }
                    is SessionState.Pending -> PendingScreen(current.role, s) { auth.signOut(); session = SessionState.LoggedOut }
                    is SessionState.LoggedIn -> RoleRouter(current.role, language) { auth.signOut(); session = SessionState.LoggedOut }
                }
            }
        }
    }
}

private sealed class AuthResult {
    data class LoggedIn(val role: Role) : AuthResult()
    data class NeedsApplication(val role: EntryRole) : AuthResult()
    data class Pending(val role: EntryRole) : AuthResult()
}

@Composable private fun LoadingScreen() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) } }

@Composable
private fun BrandHeader(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(if (compact) 44.dp else 60.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Orange, Orange2))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.LocalShipping, null, tint = Color.White, modifier = Modifier.size(if (compact) 26.dp else 36.dp))
        }
        Column {
            Text("SPEED RUN", color = Orange, fontSize = if (compact) 23.sp else 38.sp, fontWeight = FontWeight.Black)
            if (!compact) Text("طلباتك... توصل أسرع", color = Color.White, fontSize = 14.sp)
        }
    }
}

@Composable
private fun LandingScreen(language: String, onLanguage: (String) -> Unit, onRole: (EntryRole) -> Unit) {
    val s = strings(language)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                BrandHeader()
                Surface(color = Orange.copy(alpha = .13f), shape = CircleShape) { Text("⚡", fontSize = 28.sp, modifier = Modifier.padding(9.dp)) }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(30.dp), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Image(painterResource(R.drawable.speedrun_hero), null, Modifier.fillMaxWidth().height(235.dp), contentScale = ContentScale.Crop)
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(s.chooseLanguage, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            items(listOf("العربية", "English", "اردو", "বাংলা")) { lang ->
                                FilterChip(selected = language == lang, onClick = { onLanguage(lang) }, label = { Text(lang) })
                            }
                        }
                        Text(if (language == "English") "Fast food. Smart delivery. One app." else "أكل سريع • توصيل ذكي • كل شيء في تطبيق واحد", color = Muted, fontSize = 13.sp)
                    }
                }
            }
        }
        item { Text(s.start, color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black) }
        item { RoleCard("🧑", s.customer, s.customerSub, { onRole(EntryRole.CUSTOMER) }) }
        item { RoleCard("🚗", s.driver, s.driverSub, { onRole(EntryRole.DRIVER) }) }
        item { RoleCard("🏪", s.restaurant, s.restaurantSub, { onRole(EntryRole.RESTAURANT) }) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeaturePill("📍", if (language == "English") "Live tracking" else "تتبع مباشر")
                FeaturePill("🔥", if (language == "English") "Hot offers" else "عروض قوية")
                FeaturePill("🛡️", if (language == "English") "Secure" else "آمن")
            }
        }
        item { Text(s.adminNote, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) }
    }
}

@Composable private fun RoleCard(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Orange.copy(alpha = .14f), shape = RoundedCornerShape(18.dp)) { Text(emoji, fontSize = 35.sp, modifier = Modifier.padding(12.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ArrowForwardIos, null, tint = Orange, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable private fun RowScope.FeaturePill(emoji: String, text: String) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF111316)), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 24.sp)
            Text(text, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AuthScreen(role: EntryRole, language: String, onBack: () -> Unit, onCompleted: (AuthResult) -> Unit) {
    val s = strings(language)
    val context = LocalContext.current
    val activity = context as? Activity
    var mode by remember { mutableStateOf(AuthMode.PHONE) }
    var create by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    fun complete(uid: String) {
        saveUser(uid, role.name) {
            resolveRole(uid) { existing ->
                if (existing != null) onCompleted(AuthResult.LoggedIn(existing))
                else if (role == EntryRole.CUSTOMER) ensureCustomerRole(uid) { onCompleted(AuthResult.LoggedIn(Role.CUSTOMER)) }
                else checkApplication(uid) { status ->
                    when (status) {
                        "PENDING" -> onCompleted(AuthResult.Pending(role))
                        "APPROVED" -> onCompleted(AuthResult.LoggedIn(if (role == EntryRole.DRIVER) Role.DRIVER else Role.RESTAURANT))
                        else -> onCompleted(AuthResult.NeedsApplication(role))
                    }
                }
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = PaddingValues(bottom = 30.dp)) {
        item { TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(4.dp)); Text(s.back) } }
        item { BrandHeader(true) }
        item { Text(if (role == EntryRole.CUSTOMER) s.customer else if (role == EntryRole.DRIVER) s.driver else s.restaurant, color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = mode == AuthMode.PHONE, onClick = { mode = AuthMode.PHONE; message = null }, label = { Text(s.phone) }, modifier = Modifier.weight(1f))
                FilterChip(selected = mode == AuthMode.EMAIL, onClick = { mode = AuthMode.EMAIL; message = null }, label = { Text(s.email) }, modifier = Modifier.weight(1f))
            }
        }
        item {
            if (mode == AuthMode.PHONE) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        OutlinedTextField(phone, { phone = it.filter { c -> c.isDigit() || c == '+' || c == ' ' } }, Modifier.fillMaxWidth(), label = { Text(s.phone) }, placeholder = { Text("+966 5X XXX XXXX") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
                    }
                    if (verificationId == null) {
                        PrimaryButton(s.sendOtp, busy) {
                            val normalized = normalizePhone(phone)
                            if (normalized == null) message = s.international
                            else if (activity == null) message = "Activity unavailable"
                            else {
                                busy = true
                                val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                    override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) {
                                        auth.signInWithCredential(credential).addOnCompleteListener { task ->
                                            busy = false
                                            if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid)
                                            else message = task.exception?.localizedMessage
                                        }
                                    }
                                    override fun onVerificationFailed(e: FirebaseException) {
                                        busy = false
                                        message = if (e.message?.contains("not allowed", true) == true) "تسجيل الهاتف غير مفعّل في Firebase لهذا المشروع. فعّل Phone في Authentication → Sign-in method." else (e.localizedMessage ?: "Phone authentication failed")
                                    }
                                    override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                                        verificationId = id
                                        busy = false
                                        message = if (language == "English") "Verification code sent" else "تم إرسال رمز التحقق"
                                    }
                                }
                                PhoneAuthProvider.verifyPhoneNumber(PhoneAuthOptions.newBuilder(auth).setPhoneNumber(normalized).setTimeout(60L, TimeUnit.SECONDS).setActivity(activity).setCallbacks(callbacks).build())
                            }
                        }
                    } else {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            OutlinedTextField(otp, { otp = it.filter(Char::isDigit) }, Modifier.fillMaxWidth(), label = { Text("OTP") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        }
                        PrimaryButton(s.verify, busy) {
                            val id = verificationId ?: return@PrimaryButton
                            if (otp.length < 4) message = "اكتب رمز التحقق" else {
                                busy = true
                                auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp.trim())).addOnCompleteListener { task ->
                                    busy = false
                                    if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid) else message = task.exception?.localizedMessage
                                }
                            }
                        }
                        TextButton(onClick = { verificationId = null; otp = "" }) { Text(s.back) }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text(s.email) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true)
                    OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text(s.password) }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
                    TextButton(onClick = { create = !create }) { Text(if (create) s.login else s.create) }
                    PrimaryButton(if (create) s.create else s.login, busy) {
                        if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) message = "Invalid email"
                        else if (password.length < 6) message = "Password must be at least 6 characters"
                        else {
                            busy = true
                            val task = if (create) auth.createUserWithEmailAndPassword(email.trim(), password) else auth.signInWithEmailAndPassword(email.trim(), password)
                            task.addOnCompleteListener { result ->
                                busy = false
                                if (result.isSuccessful && result.result?.user != null) complete(result.result!!.user!!.uid) else message = result.exception?.localizedMessage
                            }
                        }
                    }
                }
            }
        }
        item { message?.let { Text(it, color = Red, fontSize = 12.sp) } }
        item { InfoCard("🛡️", if (role == EntryRole.CUSTOMER) "حساب العميل يُفعّل بعد التحقق." else "التسجيل هنا لا يمنح صلاحية تشغيلية. سيُطلب منك ملف انضمام كامل ومراجعة الإدارة.") }
    }
}

@Composable
private fun ApplicationFormScreen(role: EntryRole, language: String, onSubmitted: () -> Unit) {
    val driver = role == EntryRole.DRIVER
    val s = strings(language)
    var name by remember { mutableStateOf("") }
    var idNumber by remember { mutableStateOf("") }
    var license by remember { mutableStateOf("") }
    var vehicle by remember { mutableStateOf("") }
    var plate by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("الرياض") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    BackHandler { auth.signOut(); onSubmitted() }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
        item { BrandHeader(true) }
        item { Text(if (driver) "طلب انضمام السائق" else "طلب انضمام المطعم", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black) }
        item { Text(if (driver) "لن يتم تفعيل حساب السائق قبل مراجعة البيانات والمستندات والموافقة." else "لن يظهر المطعم للعملاء قبل مراجعة واعتماد الإدارة.", color = Muted) }
        item { OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text(if (driver) "الاسم الكامل" else "اسم المطعم / المسؤول") }, singleLine = true) }
        item { OutlinedTextField(idNumber, { idNumber = it }, Modifier.fillMaxWidth(), label = { Text(if (driver) "رقم الهوية" else "هوية المالك") }, singleLine = true) }
        if (driver) {
            item { OutlinedTextField(license, { license = it }, Modifier.fillMaxWidth(), label = { Text("رقم رخصة القيادة") }, singleLine = true) }
            item { OutlinedTextField(vehicle, { vehicle = it }, Modifier.fillMaxWidth(), label = { Text("نوع المركبة") }, singleLine = true) }
            item { OutlinedTextField(plate, { plate = it }, Modifier.fillMaxWidth(), label = { Text("رقم اللوحة") }, singleLine = true) }
        } else {
            item { OutlinedTextField(vehicle, { vehicle = it }, Modifier.fillMaxWidth(), label = { Text("نوع النشاط / المطعم") }, singleLine = true) }
            item { OutlinedTextField(plate, { plate = it }, Modifier.fillMaxWidth(), label = { Text("العنوان") }, singleLine = true) }
        }
        item { OutlinedTextField(city, { city = it }, Modifier.fillMaxWidth(), label = { Text("المدينة") }, singleLine = true) }
        item {
            InfoCard("📄", if (driver) "في المرحلة التالية نربط رفع الهوية والرخصة وصور المركبة بـ Firebase Storage مع مراجعة الإدارة." else "في المرحلة التالية نربط رفع مستندات المطعم والحسابات المطلوبة بـ Firebase Storage مع مراجعة الإدارة.")
        }
        item {
            PrimaryButton("إرسال طلب الانضمام", busy) {
                if (name.trim().length < 3 || idNumber.trim().length < 4 || (driver && (license.isBlank() || vehicle.isBlank() || plate.isBlank()))) {
                    error = "أكمل البيانات المطلوبة أولًا"
                } else {
                    busy = true
                    val uid = auth.currentUser?.uid
                    if (uid == null) { busy = false; error = "انتهت الجلسة، سجل الدخول مرة أخرى" }
                    else {
                        val data = mutableMapOf<String, Any>(
                            "uid" to uid,
                            "requestedRole" to role.name,
                            "status" to "PENDING",
                            "name" to name.trim(),
                            "idNumber" to idNumber.trim(),
                            "city" to city.trim(),
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                        if (driver) {
                            data["licenseNumber"] = license.trim()
                            data["vehicle"] = vehicle.trim()
                            data["plate"] = plate.trim()
                        } else {
                            data["businessType"] = vehicle.trim()
                            data["address"] = plate.trim()
                        }
                        db.collection("applications").document(uid).set(data, SetOptions.merge()).addOnSuccessListener { busy = false; onSubmitted() }.addOnFailureListener { busy = false; error = it.localizedMessage }
                    }
                }
            }
        }
        item { error?.let { Text(it, color = Red, fontSize = 12.sp) } }
    }
}

@Composable private fun PrimaryButton(text: String, busy: Boolean, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = !busy, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(17.dp)) {
        if (busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White) else Text(text, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun PendingScreen(role: EntryRole, s: UiStrings, onLogout: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(if (role == EntryRole.DRIVER) "🚗" else "🏪", fontSize = 76.sp)
        Spacer(Modifier.height(15.dp))
        Text(s.joinPending, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(10.dp))
        Text("تم استلام طلبك. الحساب سيظل غير نشط حتى تراجعه الإدارة وتوافق عليه.", color = Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        PrimaryButton(s.logout, false, onLogout)
    }
}

@Composable private fun RoleRouter(role: Role, language: String, logout: () -> Unit) {
    when (role) {
        Role.CUSTOMER -> CustomerApp(language, logout)
        Role.DRIVER -> DriverApp(language, logout)
        Role.RESTAURANT -> RestaurantApp(language, logout)
        Role.SUPERVISOR -> AdminApp(language, "المشرف", logout, false)
        Role.MANAGER -> AdminApp(language, "المدير", logout, false)
        Role.OWNER -> AdminApp(language, "المالك الرئيسي", logout, true)
    }
}

@Composable
private fun AppTopBar(title: String, subtitle: String, onBack: (() -> Unit)? = null, logout: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
        BrandHeader(true)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Black); Text(subtitle, color = Muted, fontSize = 10.sp) }
        if (logout != null) IconButton(onClick = logout) { Icon(Icons.Default.Logout, null, tint = Muted) }
    }
}

@Composable
private fun CustomerApp(language: String, logout: () -> Unit) {
    val s = strings(language)
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Restaurant?>(null) }
    var cart by remember { mutableStateOf(0) }
    var chatId by remember { mutableStateOf<String?>(null) }

    if (selected != null) {
        BackHandler { selected = null }
        RestaurantDetails(selected!!, s, cart, { cart++ }, { selected = null })
        return
    }
    if (chatId != null) {
        BackHandler { chatId = null }
        FirestoreChat(chatId!!, s) { chatId = null }
        return
    }

    Column(Modifier.fillMaxSize()) {
        AppTopBar(s.customer, "حي الخليج • الرياض", logout = logout)
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> CustomerHome(s, { selected = it }, { chatId = it })
                1 -> OrdersScreen(s)
                2 -> FavoritesScreen(s)
                else -> CustomerProfile(s, logout)
            }
        }
        BottomBar(tab, listOf(s.home, s.orders, s.favorites, s.account), listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Favorite, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun CustomerHome(s: UiStrings, onRestaurant: (Restaurant) -> Unit, onChat: (String) -> Unit) {
    var search by remember { mutableStateOf("") }
    var chatIds by remember { mutableStateOf<List<String>>(emptyList()) }
    LaunchedEffect(Unit) {
        val uid = auth.currentUser?.uid ?: return@LaunchedEffect
        db.collection("chats").whereArrayContains("participantIds", uid).limit(20).get().addOnSuccessListener { chatIds = it.documents.map { d -> d.id } }
    }
    val restaurants = remember(search) { if (search.isBlank()) demoRestaurants else demoRestaurants.filter { it.name.contains(search, true) || it.category.contains(search, true) } }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Image(painterResource(R.drawable.speedrun_food), null, Modifier.fillMaxWidth().height(170.dp), contentScale = ContentScale.Crop)
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        Text(s.offers, color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text("أكلك المفضل يوصل أسرع", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                        Text("خصومات • مطاعم قريبة • تتبع مباشر", color = Muted, fontSize = 12.sp)
                    }
                }
            }
        }
        item {
            OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth(), placeholder = { Text(s.search) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) }, singleLine = true, shape = RoundedCornerShape(17.dp))
        }
        item { Text(s.categories, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(categories) { c ->
                    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(c.emoji, fontSize = 29.sp); Text(c.title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(s.featured, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text("عرض الكل", color = Orange, fontSize = 11.sp)
            }
        }
        items(restaurants) { r -> RestaurantCard(r, s, onRestaurant) }
        if (chatIds.isNotEmpty()) {
            item {
                Card(Modifier.fillMaxWidth().clickable { onChat(chatIds.first()) }, colors = CardDefaults.cardColors(containerColor = Orange.copy(alpha = .14f)), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💬", fontSize = 28.sp); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("محادثاتك", color = Color.White, fontWeight = FontWeight.Black); Text("لديك محادثة مرتبطة بطلب فعلي", color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = Orange)
                    }
                }
            }
        }
    }
}

@Composable
private fun RestaurantCard(r: Restaurant, s: UiStrings, onClick: (Restaurant) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick(r) }, colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(21.dp)) {
        Row(Modifier.padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(88.dp).clip(RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
                Image(painterResource(R.drawable.speedrun_food), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Surface(color = Color.Black.copy(alpha = .45f), shape = CircleShape) { Text(if (r.category.contains("بيتزا")) "🍕" else if (r.category.contains("دجاج")) "🍗" else "🍔", fontSize = 27.sp, modifier = Modifier.padding(7.dp)) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 17.sp)
                Text("⭐ ${r.rating} • ${r.eta} ${s.minutes}", color = Muted, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistChip(onClick = {}, label = { Text(s.open, fontSize = 9.sp) })
                    AssistChip(onClick = {}, label = { Text(r.category, fontSize = 9.sp) })
                }
            }
            Icon(Icons.Default.ChevronRight, null, tint = Orange)
        }
    }
}

@Composable
private fun RestaurantDetails(r: Restaurant, s: UiStrings, cart: Int, onAdd: () -> Unit, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(r.name, "⭐ ${r.rating} • ${r.eta} ${s.minutes}", onBack = onBack)
        LazyColumn(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 15.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(165.dp).clip(RoundedCornerShape(24.dp))) {
                    Image(painterResource(R.drawable.speedrun_food), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Surface(Modifier.align(Alignment.BottomStart).padding(12.dp), color = Color.Black.copy(alpha = .65f), shape = RoundedCornerShape(15.dp)) { Text("🔥 عرض خاص اليوم", color = Color.White, modifier = Modifier.padding(10.dp), fontWeight = FontWeight.Bold) }
                }
            }
            item { Text(s.menu, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
            items(demoMenu) { item ->
                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Orange.copy(alpha = .12f), shape = RoundedCornerShape(15.dp)) { Text(item.emoji, fontSize = 33.sp, modifier = Modifier.padding(10.dp)) }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Black); Text(item.description, color = Muted, fontSize = 10.sp); Text("${item.price} ريال", color = Orange, fontWeight = FontWeight.Black) }
                        IconButton(onClick = onAdd) { Icon(Icons.Default.AddCircle, null, tint = Orange, modifier = Modifier.size(30.dp)) }
                    }
                }
            }
        }
        if (cart > 0) Button(onClick = {}, Modifier.fillMaxWidth().padding(14.dp).height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(17.dp)) { Text("${s.cart} • $cart", fontWeight = FontWeight.Black) }
    }
}

@Composable private fun OrdersScreen(s: UiStrings) {
    FirebaseListScreen("orders", s.orders, Icons.Default.ReceiptLong, emptyText = "لا توجد طلبات حقيقية حتى الآن")
}

@Composable private fun FavoritesScreen(s: UiStrings) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text(s.favorites, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black) }
        item { EmptyState("❤️", "لا توجد مطاعم مفضلة حتى الآن", "أضف مطاعمك المفضلة لتظهر هنا") }
    }
}

@Composable private fun CustomerProfile(s: UiStrings, logout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ProfileHeader("أحمد", "عميل Speed Run") }
        item { ProfileAction("العناوين", Icons.Default.LocationOn) }
        item { ProfileAction("طرق الدفع", Icons.Default.CreditCard) }
        item { ProfileAction("الإشعارات", Icons.Default.Notifications) }
        item { ProfileAction(s.languageName, Icons.Default.Language) }
        item { ProfileAction("الدعم والمساعدة", Icons.Default.SupportAgent) }
        item { OutlinedButton(onClick = logout, Modifier.fillMaxWidth()) { Text(s.logout) } }
    }
}

@Composable
private fun DriverApp(language: String, logout: () -> Unit) {
    val s = strings(language)
    var tab by remember { mutableStateOf(0) }
    var chatId by remember { mutableStateOf<String?>(null) }
    var online by remember { mutableStateOf(false) }
    if (chatId != null) {
        BackHandler { chatId = null }
        FirestoreChat(chatId!!, s) { chatId = null }
        return
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(s.driver, "الرياض • Speed Run", logout = logout)
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DriverDashboard(s, online) { online = it }
                1 -> FirebaseListScreen("orders", s.nearbyOrders, Icons.Default.LocalShipping, emptyText = "لا توجد طلبات متاحة الآن")
                2 -> FirebaseListScreen("orders", s.earnings, Icons.Default.Payments, emptyText = "لا توجد أرباح مسجلة حتى الآن")
                else -> DriverProfile(s, logout)
            }
        }
        BottomBar(tab, listOf("الرئيسية", s.nearbyOrders, s.earnings, s.account), listOf(Icons.Default.Home, Icons.Default.NearMe, Icons.Default.Payments, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun DriverDashboard(s: UiStrings, online: Boolean, onOnline: (Boolean) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(23.dp)) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(if (online) s.online else s.offline, color = if (online) Green else Red, fontSize = 22.sp, fontWeight = FontWeight.Black); Text("لا تستقبل طلبات إلا عندما تكون متاحًا.", color = Muted, fontSize = 11.sp) }
                    Switch(checked = online, onCheckedChange = onOnline)
                }
            }
        }
        item { MetricRow("طلبات اليوم", "0", "ابدأ أول طلب", Icons.Default.LocalShipping) }
        item { MetricRow("أرباح اليوم", "0 ريال", "", Icons.Default.Payments) }
        item { Text(s.nearbyOrders, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black) }
        item { EmptyState("🚗", "لا توجد طلبات تجريبية", "سيظهر هنا الطلب الحقيقي فقط بعد أن ينشئه عميل ويصبح متاحًا لك.") }
    }
}

@Composable private fun DriverProfile(s: UiStrings, logout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ProfileHeader("السائق", "حساب معتمد من الإدارة") }
        item { ProfileAction("بيانات المركبة", Icons.Default.DirectionsCar) }
        item { ProfileAction("المستندات", Icons.Default.Description) }
        item { ProfileAction("التقييمات", Icons.Default.Star) }
        item { OutlinedButton(onClick = logout, Modifier.fillMaxWidth()) { Text(s.logout) } }
    }
}

@Composable
private fun RestaurantApp(language: String, logout: () -> Unit) {
    val s = strings(language)
    var tab by remember { mutableStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(s.restaurant, "الرياض • لوحة المطعم", logout = logout)
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> RestaurantDashboard(s)
                1 -> FirebaseListScreen("orders", "الطلبات", Icons.Default.ReceiptLong, emptyText = "لا توجد طلبات حقيقية حتى الآن")
                2 -> FirebaseListScreen("restaurants", "قائمتي", Icons.Default.RestaurantMenu, emptyText = "لم تتم إضافة قائمة بعد")
                else -> RestaurantProfile(s, logout)
            }
        }
        BottomBar(tab, listOf("الرئيسية", "الطلبات", "القائمة", s.account), listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.RestaurantMenu, Icons.Default.Person)) { tab = it }
    }
}

@Composable private fun RestaurantDashboard(s: UiStrings) {
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { MetricRow("طلبات اليوم", "0", "لا توجد طلبات", Icons.Default.ReceiptLong) }
        item { MetricRow("مبيعات اليوم", "0 ريال", "", Icons.Default.Payments) }
        item { MetricRow("التقييم", "—", "لم يبدأ بعد", Icons.Default.Star) }
        item { EmptyState("🏪", "المطعم جاهز", "ستظهر الطلبات والمبيعات هنا عندما يبدأ التشغيل الفعلي.") }
    }
}

@Composable private fun RestaurantProfile(s: UiStrings, logout: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { ProfileHeader("مطعمي", "حساب مطعم معتمد") }
        item { ProfileAction("بيانات المطعم", Icons.Default.Storefront) }
        item { ProfileAction("مواعيد العمل", Icons.Default.Schedule) }
        item { ProfileAction("العروض والكوبونات", Icons.Default.LocalOffer) }
        item { OutlinedButton(onClick = logout, Modifier.fillMaxWidth()) { Text(s.logout) } }
    }
}

@Composable
private fun AdminApp(language: String, title: String, logout: () -> Unit, isOwner: Boolean) {
    val s = strings(language)
    var screen by remember { mutableStateOf("dashboard") }
    BackHandler(enabled = screen != "dashboard") { screen = "dashboard" }
    if (screen != "dashboard") {
        AdminSectionScreen(screen, s, isOwner) { screen = "dashboard" }
        return
    }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { AppTopBar(s.dashboard, title, logout = logout) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AdminStat("المستخدمون", "—", Icons.Default.People)
                AdminStat("السائقون", "—", Icons.Default.DirectionsCar)
                AdminStat("المطاعم", "—", Icons.Default.Storefront)
            }
        }
        item { Text("الإدارة", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
        item { AdminMenuCard("المستخدمون", "👥", Icons.Default.People) { screen = "users" } }
        item { AdminMenuCard("السائقون", "🚗", Icons.Default.DirectionsCar) { screen = "drivers" } }
        item { AdminMenuCard("المطاعم", "🏪", Icons.Default.Storefront) { screen = "restaurants" } }
        item { AdminMenuCard("طلبات الانضمام", "📋", Icons.Default.PendingActions) { screen = "applications" } }
        item { AdminMenuCard("الطلبات النشطة", "🛵", Icons.Default.LocalShipping) { screen = "orders" } }
        item { AdminMenuCard("الكوبونات والعروض", "🔥", Icons.Default.LocalOffer) { screen = "offers" } }
        item { AdminMenuCard("التقارير والإحصائيات", "📊", Icons.Default.BarChart) { screen = "reports" } }
        if (isOwner) item { AdminMenuCard("الصلاحيات وسجل العمليات", "🛡️", Icons.Default.Security) { screen = "permissions" } }
        item { OutlinedButton(onClick = logout, Modifier.fillMaxWidth()) { Text(s.logout) } }
    }
}

@Composable private fun AdminSectionScreen(screen: String, s: UiStrings, isOwner: Boolean, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(sectionTitle(s, screen), "رجوع للوحة الإدارة", onBack = onBack)
        when (screen) {
            "applications" -> ApplicationsScreen(s, isOwner)
            "users" -> FirebaseListScreen("users", s.users, Icons.Default.People, emptyText = "لا يوجد مستخدمون حتى الآن")
            "drivers" -> FirebaseRoleList(Role.DRIVER, s.drivers)
            "restaurants" -> FirebaseListScreen("restaurants", s.restaurants, Icons.Default.Storefront, emptyText = "لا توجد مطاعم معتمدة حتى الآن")
            "orders" -> FirebaseListScreen("orders", s.activeOrders, Icons.Default.LocalShipping, emptyText = "لا توجد طلبات حقيقية الآن")
            "offers" -> EmptyState("🔥", "العروض والكوبونات", "هذه الوحدة جاهزة للربط ببيانات العروض الفعلية.")
            "reports" -> EmptyState("📊", "التقارير", "ستظهر الإحصائيات من الطلبات والمبيعات الحقيقية، بدون أرقام وهمية.")
            else -> EmptyState("🛡️", "الصلاحيات والسجل", if (isOwner) "هذه المنطقة مخصصة للمالك." else "غير متاح")
        }
    }
}

@Composable
private fun ApplicationsScreen(s: UiStrings, isOwner: Boolean) {
    var docs by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    fun reload() {
        loading = true
        db.collection("applications").whereEqualTo("status", "PENDING").limit(50).get().addOnSuccessListener { docs = it.documents; loading = false }.addOnFailureListener { error = it.localizedMessage; loading = false }
    }
    LaunchedEffect(Unit) { reload() }
    if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) }
    else if (error != null) Text(error!!, color = Red, modifier = Modifier.padding(18.dp))
    else if (docs.isEmpty()) EmptyState("📋", s.noApplications, "طلبات السائقين والمطاعم تظهر هنا بعد إرسالها.")
    else LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(docs) { doc ->
            val requested = doc.getString("requestedRole") ?: "UNKNOWN"
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(19.dp)) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(if (requested == "DRIVER") "🚗 طلب سائق" else "🏪 طلب مطعم", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text("الاسم: ${doc.getString("name") ?: "—"}", color = Muted)
                    Text("المدينة: ${doc.getString("city") ?: "—"}", color = Muted)
                    Text("UID: ${doc.id}", color = Muted, fontSize = 9.sp)
                    if (isOwner) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { approveApplication(doc, requested, ::reload) }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("اعتماد") }
                        OutlinedButton(onClick = { rejectApplication(doc.id, ::reload) }) { Text("رفض") }
                    } else Text("الاعتماد النهائي للمالك فقط", color = Orange, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun approveApplication(doc: DocumentSnapshot, requested: String, reload: () -> Unit) {
    val role = if (requested == "DRIVER") Role.DRIVER.name else Role.RESTAURANT.name
    db.collection("roles").document(doc.id).set(mapOf("role" to role), SetOptions.merge()).addOnSuccessListener {
        db.collection("users").document(doc.id).set(mapOf("accountType" to role, "status" to "ACTIVE"), SetOptions.merge())
        db.collection("applications").document(doc.id).set(mapOf("status" to "APPROVED", "approvedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener { reload() }
    }
}

private fun rejectApplication(uid: String, reload: () -> Unit) { db.collection("applications").document(uid).set(mapOf("status" to "REJECTED", "rejectedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener { reload() } }

@Composable private fun FirebaseListScreen(collection: String, title: String, icon: ImageVector, emptyText: String) {
    var rows by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(collection) {
        val uid = auth.currentUser?.uid
        val query = if (collection == "orders" && uid != null) db.collection(collection).whereEqualTo("customerId", uid).limit(50) else db.collection(collection).limit(50)
        query.get().addOnSuccessListener { rows = it.documents.map { d -> d.id }; loading = false }.addOnFailureListener { error = it.localizedMessage; loading = false }
    }
    when {
        loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) }
        error != null -> Text(error!!, color = Red, modifier = Modifier.padding(18.dp))
        rows.isEmpty() -> EmptyState("📦", emptyText, "ستظهر البيانات هنا تلقائيًا عند وجود بيانات حقيقية.")
        else -> LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(rows) { text -> SimpleRow(text, icon) } }
    }
}

@Composable private fun FirebaseRoleList(role: Role, title: String) {
    var rows by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(role) { db.collection("roles").whereEqualTo("role", role.name).limit(50).get().addOnSuccessListener { rows = it.documents.map { d -> d.id }; loading = false }.addOnFailureListener { rows = emptyList(); loading = false } }
    if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) }
    else if (rows.isEmpty()) EmptyState("👥", "لا توجد سجلات", "سيظهر هنا المستخدمون المعتمدون فقط.")
    else LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(rows) { SimpleRow(it, if (role == Role.DRIVER) Icons.Default.DirectionsCar else Icons.Default.Storefront) } }
}

@Composable private fun RowScope.AdminStat(title: String, value: String, icon: ImageVector) {
    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(13.dp)) { Icon(icon, null, tint = Orange); Text(title, color = Muted, fontSize = 9.sp); Text(value, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black) } }
}

@Composable private fun AdminMenuCard(title: String, emoji: String, icon: ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Text(emoji, fontSize = 26.sp); Spacer(Modifier.width(10.dp)); Icon(icon, null, tint = Orange); Spacer(Modifier.width(10.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) }
    }
}

@Composable
private fun FirestoreChat(chatId: String, s: UiStrings, onBack: () -> Unit) {
    var messages by remember { mutableStateOf<List<DocumentSnapshot>>(emptyList()) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(chatId) {
        db.collection("chats").document(chatId).collection("messages").orderBy("createdAt").limit(100).addSnapshotListener { snap, e -> if (e != null) error = e.localizedMessage else messages = snap?.documents ?: emptyList() }
    }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(s.chat, "محادثة مرتبطة بطلب فعلي", onBack = onBack)
        if (error != null) Text(error!!, color = Red, modifier = Modifier.padding(12.dp))
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (messages.isEmpty()) item { EmptyState("💬", "لا توجد رسائل حتى الآن", "ابدأ المحادثة بإرسال أول رسالة.") }
            items(messages) { d -> ChatBubble(d.getString("text") ?: "", d.getString("senderId") == auth.currentUser?.uid) }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text("اكتب رسالة") }, singleLine = true)
            IconButton(onClick = {
                val uid = auth.currentUser?.uid
                if (uid != null && text.isNotBlank()) {
                    db.collection("chats").document(chatId).collection("messages").add(
                        mapOf("senderId" to uid, "text" to text.trim(), "createdAt" to FieldValue.serverTimestamp())
                    )
                    text = ""
                }
            }) { Icon(Icons.Default.Send, null, tint = Orange) }
        }
    }
}

@Composable private fun ChatBubble(text: String, mine: Boolean) { Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) { Surface(color = if (mine) Orange else SurfaceDark, shape = RoundedCornerShape(16.dp)) { Text(text, color = Color.White, modifier = Modifier.padding(12.dp)) } } }

@Composable private fun EmptyState(emoji: String, title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(30.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(emoji, fontSize = 52.sp); Spacer(Modifier.height(10.dp)); Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center); Spacer(Modifier.height(5.dp)); Text(subtitle, color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center) }
}

@Composable private fun InfoCard(emoji: String, text: String) { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101214)), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(emoji, fontSize = 25.sp); Spacer(Modifier.width(10.dp)); Text(text, color = Muted, fontSize = 11.sp) } } }

@Composable private fun MetricRow(title: String, value: String, extra: String, icon: ImageVector) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(48.dp).clip(CircleShape).background(Orange.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Orange) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Muted); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; if (extra.isNotBlank()) Text(extra, color = Orange, fontWeight = FontWeight.Bold, fontSize = 10.sp) } } }

@Composable private fun ProfileHeader(name: String, subtitle: String) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Orange, Orange2))), contentAlignment = Alignment.Center) { Text(name.take(1), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(14.dp)); Column { Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted) } } } }

@Composable private fun ProfileAction(text: String, icon: ImageVector) { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }

@Composable private fun SimpleRow(text: String, icon: ImageVector) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }

@Composable private fun BottomBar(selected: Int, labels: List<String>, icons: List<ImageVector>, onSelect: (Int) -> Unit) { NavigationBar(containerColor = Color(0xFF101113)) { labels.forEachIndexed { i, label -> NavigationBarItem(selected = selected == i, onClick = { onSelect(i) }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color(0xFF3A2418))) } } }

private fun sectionTitle(s: UiStrings, key: String) = when (key) { "users" -> s.users; "drivers" -> s.drivers; "restaurants" -> s.restaurants; "orders" -> s.activeOrders; "applications" -> s.applications; "offers" -> s.offersCoupons; "reports" -> s.reports; else -> s.permissions }

private fun normalizePhone(raw: String): String? {
    val digits = raw.filter(Char::isDigit)
    return when {
        raw.trim().startsWith("+966") && digits.length == 12 -> "+$digits"
        digits.startsWith("966") && digits.length == 12 -> "+$digits"
        digits.startsWith("05") && digits.length == 10 -> "+966${digits.drop(1)}"
        else -> null
    }
}

private fun saveUser(uid: String, requestedRole: String, done: () -> Unit) {
    val user = auth.currentUser ?: return done()
    val data = mapOf("uid" to uid, "email" to (user.email ?: ""), "phoneNumber" to (user.phoneNumber ?: ""), "requestedRole" to requestedRole, "updatedAt" to FieldValue.serverTimestamp())
    db.collection("users").document(uid).set(data, SetOptions.merge()).addOnCompleteListener {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token -> db.collection("users").document(uid).set(mapOf("fcmToken" to token), SetOptions.merge()) }
        done()
    }
}

private fun ensureCustomerRole(uid: String, done: () -> Unit) { db.collection("users").document(uid).set(mapOf("accountType" to Role.CUSTOMER.name, "status" to "ACTIVE", "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { done() } }

private fun checkApplication(uid: String, done: (String?) -> Unit) { db.collection("applications").document(uid).get().addOnSuccessListener { done(it.getString("status")) }.addOnFailureListener { done(null) } }

private fun resolveSession(done: (SessionState) -> Unit) {
    val user = auth.currentUser ?: return done(SessionState.LoggedOut)
    resolveRole(user.uid) { role ->
        if (role != null) {
            done(SessionState.LoggedIn(role))
        } else {
            db.collection("applications").document(user.uid).get().addOnSuccessListener { doc ->
                val requested = when (doc.getString("requestedRole")) {
                    EntryRole.RESTAURANT.name -> EntryRole.RESTAURANT
                    EntryRole.DRIVER.name -> EntryRole.DRIVER
                    else -> null
                }
                when (doc.getString("status")) {
                    "PENDING" -> if (requested != null) done(SessionState.Pending(requested)) else done(SessionState.LoggedOut)
                    else -> done(SessionState.LoggedOut)
                }
            }.addOnFailureListener { done(SessionState.LoggedOut) }
        }
    }
}

private fun resolveRole(uid: String, done: (Role?) -> Unit) {
    db.collection("roles").document(uid).get().addOnSuccessListener { snap ->
        val name = snap.getString("role")
        if (!name.isNullOrBlank()) done(runCatching { Role.valueOf(name) }.getOrNull())
        else db.collection("users").document(uid).get().addOnSuccessListener { us -> done(us.getString("accountType")?.let { runCatching { Role.valueOf(it) }.getOrNull() }) }.addOnFailureListener { done(null) }
    }.addOnFailureListener {
        db.collection("users").document(uid).get().addOnSuccessListener { us -> done(us.getString("accountType")?.let { runCatching { Role.valueOf(it) }.getOrNull() }) }.addOnFailureListener { done(null) }
    }
}
