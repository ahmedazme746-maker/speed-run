package com.speedrun.delivery

import android.app.Activity
import android.os.Bundle
import android.util.Patterns
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import java.util.concurrent.TimeUnit

private val Orange = Color(0xFFFF6A00)
private val Orange2 = Color(0xFFFF8A00)
private val Ink = Color(0xFF08090B)
private val SurfaceDark = Color(0xFF15171A)
private val Surface2 = Color(0xFF202328)
private val Muted = Color(0xFFA8ADB5)
private val Green = Color(0xFF25C77A)
private val Red = Color(0xFFE75D5D)
private val auth by lazy { FirebaseAuth.getInstance() }
private val db by lazy { FirebaseFirestore.getInstance() }

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER, OWNER }
enum class EntryRole { CUSTOMER, DRIVER, RESTAURANT }
enum class AuthMode { PHONE, EMAIL }

data class Restaurant(val id: String, val name: String, val category: String, val rating: Double, val eta: String, val price: String)
data class MenuItem(val name: String, val description: String, val price: Int)

data class UiStrings(
    val languageName: String,
    val chooseLanguage: String,
    val customer: String,
    val driver: String,
    val restaurant: String,
    val customerSub: String,
    val driverSub: String,
    val restaurantSub: String,
    val adminNote: String,
    val start: String,
    val home: String,
    val orders: String,
    val favorites: String,
    val account: String,
    val search: String,
    val categories: String,
    val featured: String,
    val offers: String,
    val open: String,
    val minutes: String,
    val menu: String,
    val cart: String,
    val add: String,
    val login: String,
    val create: String,
    val phone: String,
    val email: String,
    val password: String,
    val sendOtp: String,
    val verify: String,
    val international: String,
    val back: String,
    val joinPending: String,
    val logout: String,
    val online: String,
    val offline: String,
    val nearbyOrders: String,
    val earnings: String,
    val accept: String,
    val reject: String,
    val chat: String,
    val dashboard: String,
    val users: String,
    val drivers: String,
    val restaurants: String,
    val activeOrders: String,
    val applications: String,
    val offersCoupons: String,
    val reports: String,
    val permissions: String,
    val noApplications: String
)

private val AR = UiStrings("العربية", "اختر اللغة", "العميل", "السائق / المندوب", "المطعم", "اطلب طعامك وتابع الطلب لحظة بلحظة", "استقبل الطلبات ووصلها وشاهد أرباحك", "أدر المنيو والطلبات والعروض", "الحسابات الإدارية تُمنح من لوحة الإدارة فقط", "ابدأ الآن", "الرئيسية", "طلباتي", "المفضلة", "حسابي", "ابحث عن مطعم أو صنف...", "التصنيفات", "المطاعم المميزة", "عروض اليوم", "مفتوح", "دقيقة", "القائمة", "السلة", "إضافة", "تسجيل الدخول", "إنشاء حساب", "الجوال", "البريد الإلكتروني", "كلمة المرور", "إرسال رمز التحقق", "تأكيد الرمز", "اكتب الرقم بصيغة دولية مثل +9665XXXXXXXX", "رجوع", "طلب انضمام", "تسجيل الخروج", "متاح الآن", "غير متاح", "طلبات قريبة", "أرباحي", "قبول", "رفض", "محادثة", "لوحة الإدارة", "المستخدمون", "السائقون", "المطاعم", "الطلبات النشطة", "طلبات الانضمام", "الكوبونات والعروض", "التقارير والإحصائيات", "الصلاحيات والسجل", "لا توجد طلبات انضمام حاليًا")
private val EN = UiStrings("English", "Choose language", "Customer", "Driver / Courier", "Restaurant", "Order food and track it live", "Receive deliveries and track earnings", "Manage your menu, orders and offers", "Admin accounts are granted only from the admin panel", "Get started", "Home", "Orders", "Favorites", "Account", "Search restaurants or dishes...", "Categories", "Featured restaurants", "Today's offers", "Open", "min", "Menu", "Cart", "Add", "Sign in", "Create account", "Phone", "Email", "Password", "Send verification code", "Verify code", "Enter an international number like +9665XXXXXXXX", "Back", "Join request", "Sign out", "Online", "Offline", "Nearby orders", "Earnings", "Accept", "Reject", "Chat", "Admin dashboard", "Users", "Drivers", "Restaurants", "Active orders", "Join requests", "Coupons & offers", "Reports & analytics", "Permissions & audit", "No join requests")
private val UR = UiStrings("اردو", "زبان منتخب کریں", "گاہک", "ڈرائیور / کورئیر", "ریستوران", "کھانا آرڈر کریں اور لائیو ٹریک کریں", "آرڈرز وصول کریں اور آمدنی دیکھیں", "مینو، آرڈرز اور آفرز سنبھالیں", "ایڈمن اکاؤنٹس صرف ایڈمن پینل سے دیے جاتے ہیں", "شروع کریں", "ہوم", "آرڈرز", "پسندیدہ", "اکاؤنٹ", "ریستوران یا کھانا تلاش کریں...", "زمرے", "نمایاں ریستوران", "آج کی آفرز", "کھلا", "منٹ", "مینو", "کارٹ", "شامل کریں", "لاگ اِن", "اکاؤنٹ بنائیں", "فون", "ای میل", "پاس ورڈ", "تصدیقی کوڈ بھیجیں", "کوڈ کی تصدیق", "بین الاقوامی نمبر لکھیں جیسے +9665XXXXXXXX", "واپس", "شمولیت کی درخواست", "لاگ آؤٹ", "آن لائن", "آف لائن", "قریب کے آرڈرز", "کمائی", "قبول", "رد", "چیٹ", "ایڈمن پینل", "صارفین", "ڈرائیور", "ریستوران", "فعال آرڈرز", "شمولیت کی درخواستیں", "کوپن اور آفرز", "رپورٹس اور اعدادوشمار", "اختیارات اور لاگ", "فی الحال کوئی درخواست نہیں")
private val BN = UiStrings("বাংলা", "ভাষা নির্বাচন করুন", "গ্রাহক", "ড্রাইভার / কুরিয়ার", "রেস্টুরেন্ট", "খাবার অর্ডার করুন ও লাইভ ট্র্যাক করুন", "অর্ডার নিন ও আয় দেখুন", "মেনু, অর্ডার ও অফার পরিচালনা করুন", "অ্যাডমিন অ্যাকাউন্ট শুধু অ্যাডমিন প্যানেল থেকে দেওয়া হয়", "শুরু করুন", "হোম", "অর্ডার", "পছন্দের", "অ্যাকাউন্ট", "রেস্টুরেন্ট বা খাবার খুঁজুন...", "ক্যাটাগরি", "জনপ্রিয় রেস্টুরেন্ট", "আজকের অফার", "খোলা", "মিনিট", "মেনু", "কার্ট", "যোগ করুন", "সাইন ইন", "অ্যাকাউন্ট তৈরি", "ফোন", "ইমেইল", "পাসওয়ার্ড", "ভেরিফিকেশন কোড পাঠান", "কোড যাচাই", "আন্তর্জাতিক নম্বর লিখুন যেমন +9665XXXXXXXX", "ফিরে যান", "যোগদানের অনুরোধ", "সাইন আউট", "অনলাইন", "অফলাইন", "কাছের অর্ডার", "আয়", "গ্রহণ", "বাতিল", "চ্যাট", "অ্যাডমিন ড্যাশবোর্ড", "ব্যবহারকারী", "ড্রাইভার", "রেস্টুরেন্ট", "সক্রিয় অর্ডার", "যোগদানের অনুরোধ", "কুপন ও অফার", "রিপোর্ট ও অ্যানালিটিক্স", "অনুমতি ও লগ", "কোনো অনুরোধ নেই")

private fun strings(language: String): UiStrings = when (language) { "English" -> EN; "اردو" -> UR; "বাংলা" -> BN; else -> AR }
private fun isRtl(language: String) = language == "العربية" || language == "اردو"

private val demoRestaurants = listOf(
    Restaurant("r1", "ماكدونالدز", "برجر", 4.8, "20-30", "$$"),
    Restaurant("r2", "كنتاكي", "دجاج", 4.6, "20-35", "$$"),
    Restaurant("r3", "بيتزا الخليج", "بيتزا", 4.7, "25-35", "$$"),
    Restaurant("r4", "مشويات النخبة", "مشويات", 4.6, "30-40", "$$$")
)
private val demoMenu = listOf(
    MenuItem("وجبة برجر مالك", "برجر، جبنة، بطاطس", 28),
    MenuItem("تشكن مالك", "دجاج مقرمش وصوص خاص", 24),
    MenuItem("بطاطس كبيرة", "بطاطس مع صوص", 12),
    MenuItem("كولا 330 مل", "مشروب بارد", 8)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SpeedRunApp() } }
}

@Composable
fun SpeedRunApp() {
    var language by remember { mutableStateOf("العربية") }
    var entryRole by remember { mutableStateOf<EntryRole?>(null) }
    var loggedRole by remember { mutableStateOf<Role?>(null) }
    var pending by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(auth.currentUser != null) }
    val s = strings(language)
    LaunchedEffect(Unit) {
        val user = auth.currentUser
        if (user == null) loading = false else resolveRole(user.uid) { role -> loggedRole = role; loading = false }
    }
    val scheme = darkColorScheme(primary = Orange, background = Ink, surface = SurfaceDark)
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides if (isRtl(language)) LayoutDirection.Rtl else LayoutDirection.Ltr) {
            Surface(Modifier.fillMaxSize(), color = Ink) {
                when {
                    loading -> LoadingScreen()
                    pending -> PendingScreen(s, onLogout = { auth.signOut(); pending = false; entryRole = null })
                    loggedRole != null -> RoleRouter(loggedRole!!, language) { auth.signOut(); loggedRole = null }
                    entryRole != null -> AuthScreen(entryRole!!, language, { entryRole = null }) { result ->
                        when (result) { is AuthResult.LoggedIn -> loggedRole = result.role; is AuthResult.Pending -> pending = true }
                    }
                    else -> LandingScreen(language, { language = it }) { entryRole = it }
                }
            }
        }
    }
}

private sealed class AuthResult { data class LoggedIn(val role: Role) : AuthResult(); data class Pending(val title: String) : AuthResult() }

@Composable private fun LoadingScreen() { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) } }

@Composable
private fun BrandHeader(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(if (compact) 38.dp else 50.dp).clip(RoundedCornerShape(14.dp)).background(Orange), contentAlignment = Alignment.Center) { Icon(Icons.Default.LocalShipping, null, tint = Color.White, modifier = Modifier.size(if (compact) 23.dp else 30.dp)) }
        Column { Text("SPEED RUN", color = Orange, fontSize = if (compact) 23.sp else 34.sp, fontWeight = FontWeight.Black); if (!compact) Text("طلباتك... توصل أسرع", color = Color.White, fontSize = 14.sp) }
    }
}

@Composable
private fun LandingScreen(language: String, onLanguage: (String) -> Unit, onRole: (EntryRole) -> Unit) {
    val s = strings(language)
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(vertical = 22.dp)) {
        item { BrandHeader() }
        item {
            Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Image(painterResource(com.speedrun.delivery.R.drawable.speedrun_hero), null, modifier = Modifier.fillMaxWidth().height(230.dp), contentScale = ContentScale.Crop)
                    Column(Modifier.padding(18.dp)) {
                        Text(s.chooseLanguage, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) { listOf("العربية", "English", "اردو", "বাংলা").forEach { lang -> FilterChip(selected = language == lang, onClick = { onLanguage(lang) }, label = { Text(lang, fontSize = 11.sp) }, modifier = Modifier.weight(1f)) } }
                    }
                }
            }
        }
        item { Text(s.start, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black) }
        item { RoleCard(s.customer, s.customerSub, Icons.Default.Person, { onRole(EntryRole.CUSTOMER) }) }
        item { RoleCard(s.driver, s.driverSub, Icons.Default.DirectionsCar, { onRole(EntryRole.DRIVER) }) }
        item { RoleCard(s.restaurant, s.restaurantSub, Icons.Default.Storefront, { onRole(EntryRole.RESTAURANT) }) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeaturePill(Icons.Default.LocationOn, if (language == "English") "Live tracking" else if (language == "বাংলা") "লাইভ ট্র্যাক" else "تتبع مباشر")
                FeaturePill(Icons.Default.LocalOffer, if (language == "English") "Offers" else if (language == "বাংলা") "অফার" else "عروض")
                FeaturePill(Icons.Default.SupportAgent, "24/7")
            }
        }
        item { Text(s.adminNote, color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)) }
    }
}

@Composable private fun RoleCard(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Orange, Orange2))), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(29.dp)) }
            Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(4.dp)); Text(subtitle, color = Muted, fontSize = 12.sp) }
            Icon(Icons.Default.ArrowForwardIos, null, tint = Orange, modifier = Modifier.size(17.dp))
        }
    }
}

@Composable private fun FeaturePill(icon: ImageVector, text: String) { Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFF101214)), shape = RoundedCornerShape(15.dp)) { Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Orange, modifier = Modifier.size(20.dp)); Text(text, color = Color.White, fontSize = 9.sp) } } }

@Composable
private fun AuthScreen(role: EntryRole, language: String, onBack: () -> Unit, onCompleted: (AuthResult) -> Unit) {
    val s = strings(language); val context = LocalContext.current; val activity = context as? Activity
    var mode by remember { mutableStateOf(AuthMode.PHONE) }; var create by remember { mutableStateOf(true) }
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var otp by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }; var busy by remember { mutableStateOf(false) }; var message by remember { mutableStateOf<String?>(null) }
    fun complete(uid: String) {
        val requested = role.name
        saveUser(uid, requested) { resolveRole(uid) { existing ->
            if (existing != null) onCompleted(AuthResult.LoggedIn(existing))
            else if (role == EntryRole.CUSTOMER) ensureCustomerRole(uid) { onCompleted(AuthResult.LoggedIn(Role.CUSTOMER)) }
            else createApplication(uid, requested) { onCompleted(AuthResult.Pending(if (role == EntryRole.DRIVER) "${s.driver} • ${s.joinPending}" else "${s.restaurant} • ${s.joinPending}")) }
        } }
    }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp), contentPadding = PaddingValues(bottom = 25.dp)) {
        item { TextButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(4.dp)); Text(s.back) } }
        item { BrandHeader(true) }
        item { Text(if (role == EntryRole.CUSTOMER) s.customer else if (role == EntryRole.DRIVER) s.driver else s.restaurant, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { FilterChip(mode == AuthMode.PHONE, { mode = AuthMode.PHONE; message = null }, label = { Text(s.phone) }, modifier = Modifier.weight(1f)); FilterChip(mode == AuthMode.EMAIL, { mode = AuthMode.EMAIL; message = null }, label = { Text(s.email) }, modifier = Modifier.weight(1f)) } }
        item {
            if (mode == AuthMode.PHONE) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(phone, { phone = it }, Modifier.fillMaxWidth(), label = { Text(s.phone) }, placeholder = { Text("+9665XXXXXXXX") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true)
                    if (verificationId == null) PrimaryButton(s.sendOtp, busy) {
                        if (activity == null || !phone.trim().startsWith("+")) message = s.international else {
                            busy = true
                            val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                override fun onVerificationCompleted(credential: com.google.firebase.auth.PhoneAuthCredential) { auth.signInWithCredential(credential).addOnCompleteListener { task -> busy = false; if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid) else message = task.exception?.localizedMessage } }
                                override fun onVerificationFailed(e: FirebaseException) { busy = false; message = e.localizedMessage ?: "Phone authentication failed" }
                                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) { verificationId = id; busy = false; message = if (language == "English") "Verification code sent" else "تم إرسال رمز التحقق" }
                            }
                            PhoneAuthProvider.verifyPhoneNumber(PhoneAuthOptions.newBuilder(auth).setPhoneNumber(phone.trim()).setTimeout(60L, TimeUnit.SECONDS).setActivity(activity).setCallbacks(callbacks).build())
                        }
                    } else {
                        OutlinedTextField(otp, { otp = it }, Modifier.fillMaxWidth(), label = { Text("OTP") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                        PrimaryButton(s.verify, busy) { val id = verificationId ?: return@PrimaryButton; busy = true; auth.signInWithCredential(PhoneAuthProvider.getCredential(id, otp.trim())).addOnCompleteListener { task -> busy = false; if (task.isSuccessful && task.result?.user != null) complete(task.result!!.user!!.uid) else message = task.exception?.localizedMessage } }
                        TextButton(onClick = { verificationId = null; otp = "" }) { Text(s.back) }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text(s.email) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), singleLine = true)
                    OutlinedTextField(password, { password = it }, Modifier.fillMaxWidth(), label = { Text(s.password) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), singleLine = true)
                    TextButton(onClick = { create = !create }) { Text(if (create) s.login else s.create) }
                    PrimaryButton(if (create) s.create else s.login, busy) {
                        if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) message = "Invalid email" else if (password.length < 6) message = "Password must be at least 6 characters" else { busy = true; val task = if (create) auth.createUserWithEmailAndPassword(email.trim(), password) else auth.signInWithEmailAndPassword(email.trim(), password); task.addOnCompleteListener { result -> busy = false; if (result.isSuccessful && result.result?.user != null) complete(result.result!!.user!!.uid) else message = result.exception?.localizedMessage } }
                    }
                }
            }
        }
        item { message?.let { Text(it, color = Red, fontSize = 12.sp) } }
        item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF101214)), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Security, null, tint = Orange); Spacer(Modifier.width(10.dp)); Text(if (role == EntryRole.CUSTOMER) "${s.customer}: حسابك يبدأ بعد التحقق" else s.adminNote, color = Muted, fontSize = 12.sp) } } }
    }
}

@Composable private fun PrimaryButton(text: String, busy: Boolean, onClick: () -> Unit) { Button(onClick = onClick, enabled = !busy, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(16.dp)) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White) else Text(text, fontWeight = FontWeight.Bold) } }

@Composable private fun PendingScreen(s: UiStrings, onLogout: () -> Unit) { Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) { Icon(Icons.Default.PendingActions, null, tint = Orange, modifier = Modifier.size(76.dp)); Spacer(Modifier.height(18.dp)); Text(s.joinPending, color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(10.dp)); Text(if (s.languageName == "English") "Your request was received. The account becomes active after admin approval." else "تم استلام طلبك. الحساب سيصبح نشطًا بعد مراجعة واعتماد الإدارة.", color = Muted, textAlign = TextAlign.Center); Spacer(Modifier.height(22.dp)); PrimaryButton(s.logout, false, onLogout) } }

@Composable private fun RoleRouter(role: Role, language: String, logout: () -> Unit) { when (role) { Role.CUSTOMER -> CustomerApp(language, logout); Role.DRIVER -> DriverApp(language, logout); Role.RESTAURANT -> RestaurantApp(language, logout); Role.SUPERVISOR -> AdminApp(language, "المشرف", logout, false); Role.MANAGER -> AdminApp(language, "المدير", logout, false); Role.OWNER -> AdminApp(language, "المالك الرئيسي", logout, true) } }

@Composable private fun AppTopBar(title: String, subtitle: String, logout: () -> Unit) { Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) { BrandHeader(true); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 10.sp) }; IconButton(onClick = logout) { Icon(Icons.Default.Logout, null, tint = Muted) } } }

@Composable
private fun CustomerApp(language: String, logout: () -> Unit) {
    val s = strings(language); var tab by remember { mutableStateOf(0) }; var selected by remember { mutableStateOf<Restaurant?>(null) }; var cart by remember { mutableStateOf(0) }; var chat by remember { mutableStateOf(false) }
    if (selected != null) { RestaurantDetails(selected!!, s, cart, { cart++ }, { selected = null }) ; return }
    if (chat) { DriverChat(s, { chat = false }); return }
    Column(Modifier.fillMaxSize()) {
        AppTopBar(s.customer, "حي الخليج • الرياض", logout)
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> CustomerHome(s, { selected = it }, { chat = true })
                1 -> SimpleListScreen(s.orders, listOf("#1250 • ماكدونالدز • قيد التوصيل", "#1248 • بيتزا الخليج • تم التسليم", "#1242 • مذاق عربي • ملغي"), Icons.Default.ReceiptLong)
                2 -> SimpleListScreen(s.favorites, demoRestaurants.map { it.name }, Icons.Default.Favorite)
                else -> CustomerProfile(s, logout)
            }
        }
        BottomBar(tab, listOf(s.home, s.orders, s.favorites, s.account), listOf(Icons.Default.Home, Icons.Default.ReceiptLong, Icons.Default.Favorite, Icons.Default.Person)) { tab = it }
    }
}

@Composable
private fun CustomerHome(s: UiStrings, onRestaurant: (Restaurant) -> Unit, onChat: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column { Image(painterResource(R.drawable.speedrun_food), null, Modifier.fillMaxWidth().height(170.dp), contentScale = ContentScale.Crop); Column(Modifier.padding(15.dp)) { Text(s.offers, color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold); Text(if (s.languageName == "English") "Your favorites delivered faster" else "أكلك المفضل يوصل أسرع", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Black); Spacer(Modifier.height(10.dp)); Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(if (s.languageName == "English") "Order now" else "اطلب الآن") } } } } }
        item { OutlinedTextField("", {}, Modifier.fillMaxWidth(), placeholder = { Text(s.search) }, leadingIcon = { Icon(Icons.Default.Search, null) }, shape = RoundedCornerShape(16.dp), singleLine = true) }
        item { Text(s.categories, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf(Icons.Default.Fastfood, Icons.Default.LocalPizza, Icons.Default.LocalDrink, Icons.Default.LocalOffer, Icons.Default.MoreHoriz).forEachIndexed { i, icon -> CategoryChip(icon, listOf("برجر", "بيتزا", "مشروبات", "عروض", "المزيد")[i]) } } }
        item { Row(verticalAlignment = Alignment.CenterVertically) { Text(s.featured, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Text(if (s.languageName == "English") "See all" else "عرض الكل", color = Orange, fontSize = 12.sp) } }
        items(demoRestaurants) { r -> RestaurantCard(r, s, { onRestaurant(r) }) }
        item { Card(Modifier.fillMaxWidth().clickable(onClick = onChat), colors = CardDefaults.cardColors(containerColor = Color(0xFF161A1F)), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Chat, null, tint = Orange); Spacer(Modifier.width(10.dp)); Column { Text(s.chat, color = Color.White, fontWeight = FontWeight.Bold); Text(if (s.languageName == "English") "Contact your driver from the order" else "تواصل مع السائق من داخل الطلب", color = Muted, fontSize = 11.sp) } } } }
    }
}

@Composable private fun CategoryChip(icon: ImageVector, text: String) { Card(Modifier.width(72.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(17.dp)) { Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = Orange, modifier = Modifier.size(23.dp)); Text(text, color = Color.White, fontSize = 9.sp) } } }

@Composable private fun RestaurantCard(r: Restaurant, s: UiStrings, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp)) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(80.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Color(0xFF2A2C31), Orange.copy(alpha = .7f)))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Restaurant, null, tint = Color.White, modifier = Modifier.size(38.dp)) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(r.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("⭐ ${r.rating} • ${r.eta} ${s.minutes}", color = Muted, fontSize = 11.sp); Spacer(Modifier.height(5.dp)); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { AssistChip(onClick = {}, label = { Text(s.open, fontSize = 9.sp) }); AssistChip(onClick = {}, label = { Text(r.category, fontSize = 9.sp) }) } }; Icon(Icons.Default.ChevronRight, null, tint = Orange) } } }

@Composable private fun RestaurantDetails(r: Restaurant, s: UiStrings, cart: Int, onAdd: () -> Unit, onBack: () -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Column(Modifier.weight(1f)) { Text(r.name, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("⭐ ${r.rating} • ${r.eta} ${s.minutes}", color = Muted, fontSize = 11.sp) }; BadgedIcon(Icons.Default.ShoppingCart, cart, {}) }; LazyColumn(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Box(Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF24272C), Orange))), contentAlignment = Alignment.Center) { Icon(Icons.Default.RestaurantMenu, null, tint = Color.White, modifier = Modifier.size(70.dp)) } }; item { Text(s.menu, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; items(demoMenu) { item -> Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(17.dp)) { Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF292C31)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Fastfood, null, tint = Orange) }; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Bold); Text(item.description, color = Muted, fontSize = 10.sp); Text("${item.price} ريال", color = Orange, fontWeight = FontWeight.Bold) }; IconButton(onClick = onAdd) { Icon(Icons.Default.AddCircle, null, tint = Orange) } } } } }; if (cart > 0) Button(onClick = {}, Modifier.fillMaxWidth().padding(14.dp).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text("${s.cart} • $cart") } } }

@Composable private fun BadgedIcon(icon: ImageVector, count: Int, onClick: () -> Unit) { Box { IconButton(onClick = onClick) { Icon(icon, null, tint = Color.White) }; if (count > 0) Box(Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) { Text(count.toString(), color = Color.White, fontSize = 9.sp) } } }

@Composable private fun CustomerProfile(s: UiStrings, logout: () -> Unit) { LazyColumn(Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { ProfileHeader("أحمد", if (s.languageName == "English") "Verified customer" else "عميل موثق") }; item { ProfileAction(if (s.languageName == "English") "Addresses" else "العناوين", Icons.Default.LocationOn) }; item { ProfileAction(if (s.languageName == "English") "Payment methods" else "طرق الدفع", Icons.Default.CreditCard) }; item { ProfileAction(if (s.languageName == "English") "Notifications" else "الإشعارات", Icons.Default.Notifications) }; item { ProfileAction(s.languageName, Icons.Default.Language) }; item { ProfileAction(if (s.languageName == "English") "Support" else "الدعم", Icons.Default.SupportAgent) }; item { OutlinedButton(onClick = logout, Modifier.fillMaxWidth()) { Text(s.logout) } } } }

@Composable private fun DriverApp(language: String, logout: () -> Unit) { val s = strings(language); var online by remember { mutableStateOf(false) }; var tab by remember { mutableStateOf(0) }; var chat by remember { mutableStateOf(false) }; if (chat) { DriverChat(s) { chat = false }; return }; Column(Modifier.fillMaxSize()) { AppTopBar(s.driver, "الرياض • Speed Run", logout); Box(Modifier.weight(1f)) { when (tab) { 0 -> LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(if (online) s.online else s.offline, color = if (online) Green else Red, fontSize = 21.sp, fontWeight = FontWeight.Black); Text(if (language == "English") "Receive nearby orders" else "فعّل حالتك لاستقبال الطلبات", color = Muted, fontSize = 11.sp) }; Switch(online, { online = it }) } } }; item { MetricRow(if (language == "English") "Today" else "طلبات اليوم", "5", "320 ريال", Icons.Default.LocalShipping) }; item { Text(s.nearbyOrders, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }; items(listOf("#1251 • برجر تايم • 28 ريال • 1.2 كم", "#1252 • بيتزا الخليج • 42 ريال • 2.0 كم")) { DriverOrderCard(it, s, { chat = true }) } }; 1 -> SimpleListScreen(s.earnings, listOf("اليوم: 320 ريال", "هذا الأسبوع: 1,840 ريال", "هذا الشهر: 7,420 ريال"), Icons.Default.Payments); else -> CustomerProfile(s, logout) } }; BottomBar(tab, listOf(s.home, s.earnings, s.account), listOf(Icons.Default.Home, Icons.Default.Payments, Icons.Default.Person)) { tab = it } } }

@Composable private fun DriverOrderCard(text: String, s: UiStrings, onChat: () -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(text, color = Color.White, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = {}, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(s.accept) }; OutlinedButton(onClick = {}, Modifier.weight(1f)) { Text(s.reject) }; IconButton(onClick = onChat) { Icon(Icons.Default.Chat, null, tint = Orange) } } } } }

@Composable private fun RestaurantApp(language: String, logout: () -> Unit) { val s = strings(language); var open by remember { mutableStateOf(true) }; var tab by remember { mutableStateOf(0) }; Column(Modifier.fillMaxSize()) { AppTopBar(s.restaurant, "لوحة مطعمك • إدارة خاصة", logout); Box(Modifier.weight(1f)) { when (tab) { 0 -> LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) { item { MetricRow("طلبات اليوم", "12", "420 ريال", Icons.Default.ReceiptLong) }; item { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Text(if (open) s.open else s.offline, color = if (open) Green else Red, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Switch(open, { open = it }) } }; item { Text(s.orders, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }; items(listOf("#1250 • 28 ريال • جديد", "#1249 • 52 ريال • قيد التحضير", "#1248 • 34 ريال • جاهز للاستلام")) { RestaurantOrderCard(it, s) } }; 1 -> MenuManagement(s); else -> CustomerProfile(s, logout) } }; BottomBar(tab, listOf(s.orders, s.menu, s.account), listOf(Icons.Default.ReceiptLong, Icons.Default.MenuBook, Icons.Default.Person)) { tab = it } } }

@Composable private fun RestaurantOrderCard(text: String, s: UiStrings) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(text, color = Color.White, fontWeight = FontWeight.Bold); Text(if (s.languageName == "English") "Open order and update status" else "افتح الطلب وغيّر حالته", color = Muted, fontSize = 10.sp) }; Button(onClick = {}, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(if (s.languageName == "English") "Open" else "فتح") } } } }

@Composable private fun MenuManagement(s: UiStrings) { LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Text(s.menu, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; item { PrimaryButton(if (s.languageName == "English") "Add item" else "إضافة صنف جديد", false, {}) }; items(demoMenu) { item -> Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(16.dp)) { Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(item.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${item.price} ريال", color = Orange) }; IconButton(onClick = {}) { Icon(Icons.Default.Edit, null, tint = Orange) } } } } } }

@Composable private fun AdminApp(language: String, title: String, logout: () -> Unit, isOwner: Boolean) { val s = strings(language); var section by remember { mutableStateOf("dashboard") }; Column(Modifier.fillMaxSize()) { AppTopBar(if (language == "English") "Admin • $title" else "لوحة $title", s.permissions, logout); Box(Modifier.weight(1f)) { if (section == "dashboard") AdminDashboard(s, { section = it }) else AdminSection(s, section, isOwner, { section = "dashboard" }) } } }

@Composable private fun AdminDashboard(s: UiStrings, onSection: (String) -> Unit) {
    var users by remember { mutableStateOf<Int?>(null) }; var restaurants by remember { mutableStateOf<Int?>(null) }; var orders by remember { mutableStateOf<Int?>(null) }; var apps by remember { mutableStateOf<Int?>(null) }
    LaunchedEffect(Unit) { listOf("users" to { n: Int -> users = n }, "restaurants" to { n: Int -> restaurants = n }, "orders" to { n: Int -> orders = n }, "applications" to { n: Int -> apps = n }).forEach { (name, set) -> db.collection(name).get().addOnSuccessListener { set(it.size()) }.addOnFailureListener { set(0) } } }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text(s.dashboard, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black); Text(if (s.languageName == "English") "Live data from Firebase" else "البيانات تُقرأ من Firebase مباشرة", color = Muted, fontSize = 11.sp) } } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AdminStat(s.users, users?.toString() ?: "…", Icons.Default.People); AdminStat(s.restaurants, restaurants?.toString() ?: "…", Icons.Default.Storefront) } }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { AdminStat(s.activeOrders, orders?.toString() ?: "…", Icons.Default.ReceiptLong); AdminStat(s.applications, apps?.toString() ?: "…", Icons.Default.Assignment) } }
        item { Text(if (s.languageName == "English") "Control center" else "مركز التحكم", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        val menu = listOf("users" to Pair(s.users, Icons.Default.People), "drivers" to Pair(s.drivers, Icons.Default.DirectionsCar), "restaurants" to Pair(s.restaurants, Icons.Default.Storefront), "orders" to Pair(s.activeOrders, Icons.Default.LocationOn), "applications" to Pair(s.applications, Icons.Default.Assignment), "offers" to Pair(s.offersCoupons, Icons.Default.LocalOffer), "reports" to Pair(s.reports, Icons.Default.BarChart), "permissions" to Pair(s.permissions, Icons.Default.Security))
        items(menu) { (key, pair) -> AdminMenuCard(pair.first, pair.second) { onSection(key) } }
    }
}

@Composable private fun AdminSection(s: UiStrings, section: String, isOwner: Boolean, onBack: () -> Unit) { Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Text(sectionTitle(s, section), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold) }; when (section) { "applications" -> AdminApplications(s, isOwner); "users" -> FirebaseList("users", s.users, Icons.Default.People); "drivers" -> FirebaseRoleList(Role.DRIVER, s.drivers); "restaurants" -> FirebaseRoleList(Role.RESTAURANT, s.restaurants); "orders" -> FirebaseList("orders", s.activeOrders, Icons.Default.ReceiptLong); "offers" -> SimpleListScreen(s.offersCoupons, listOf("خصم 20% للمستخدم الجديد", "توصيل مجاني اليوم", "SPEED10"), Icons.Default.LocalOffer); "reports" -> SimpleListScreen(s.reports, listOf("مبيعات اليوم", "عدد الطلبات", "متوسط التقييم"), Icons.Default.BarChart); else -> SimpleListScreen(s.permissions, listOf("OWNER • Full access", "MANAGER • Operations", "SUPERVISOR • Monitoring", "Audit log enabled"), Icons.Default.Security) } } }

@Composable private fun AdminApplications(s: UiStrings, isOwner: Boolean) { var loading by remember { mutableStateOf(true) }; var rows by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }; var message by remember { mutableStateOf<String?>(null) }; fun reload() { loading = true; db.collection("applications").get().addOnSuccessListener { snap -> rows = snap.documents.filter { (it.getString("status") ?: "PENDING") == "PENDING" }.map { it.id to (it.getString("requestedRole") ?: "UNKNOWN") }; loading = false }.addOnFailureListener { message = it.localizedMessage; loading = false } }; LaunchedEffect(Unit) { reload() }; if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) } else if (rows.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(s.noApplications, color = Muted) } else LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { items(rows) { (uid, requested) -> Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(17.dp)) { Column(Modifier.padding(14.dp)) { Text(if (requested == "DRIVER") s.driver else s.restaurant, color = Color.White, fontWeight = FontWeight.Bold); Text("UID: $uid", color = Muted, fontSize = 9.sp); Spacer(Modifier.height(9.dp)); if (isOwner) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Button(onClick = { db.collection("roles").document(uid).set(mapOf("role" to requested), SetOptions.merge()).addOnSuccessListener { db.collection("users").document(uid).set(mapOf("accountType" to requested, "status" to "ACTIVE"), SetOptions.merge()); db.collection("applications").document(uid).set(mapOf("status" to "APPROVED", "approvedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnSuccessListener { reload() } }.addOnFailureListener { message = it.localizedMessage } }, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text(if (s.languageName == "English") "Approve" else "اعتماد") }; OutlinedButton(onClick = { db.collection("applications").document(uid).set(mapOf("status" to "REJECTED"), SetOptions.merge()).addOnSuccessListener { reload() } }) { Text(if (s.languageName == "English") "Reject" else "رفض") } } else Text(if (s.languageName == "English") "Owner approval required" else "الاعتماد النهائي للمالك فقط", color = Orange, fontSize = 11.sp) } } } } }

@Composable private fun FirebaseList(collection: String, title: String, icon: ImageVector) { var rows by remember { mutableStateOf<List<String>>(emptyList()) }; var loading by remember { mutableStateOf(true) }; LaunchedEffect(collection) { db.collection(collection).limit(50).get().addOnSuccessListener { rows = it.documents.map { d -> d.id }.ifEmpty { listOf("No records") }; loading = false }.addOnFailureListener { rows = listOf("Firebase: ${it.localizedMessage ?: "error"}"); loading = false } }; if (loading) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Orange) } else SimpleListScreen(title, rows, icon) }

@Composable private fun FirebaseRoleList(role: Role, title: String) { var rows by remember { mutableStateOf<List<String>>(emptyList()) }; LaunchedEffect(role) { db.collection("roles").whereEqualTo("role", role.name).limit(50).get().addOnSuccessListener { rows = it.documents.map { d -> d.id }.ifEmpty { listOf("No ${role.name.lowercase()} records") } } }; SimpleListScreen(title, rows, if (role == Role.DRIVER) Icons.Default.DirectionsCar else Icons.Default.Storefront) }

@Composable private fun AdminStat(title: String, value: String, icon: ImageVector) { Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) { Column(Modifier.padding(14.dp)) { Icon(icon, null, tint = Orange); Text(title, color = Muted, fontSize = 10.sp); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) } } }
@Composable private fun AdminMenuCard(title: String, icon: ImageVector, onClick: () -> Unit) { Card(Modifier.fillMaxWidth().clickable(onClick = onClick), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(17.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(title, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }

@Composable private fun DriverChat(s: UiStrings, onBack: () -> Unit) { var text by remember { mutableStateOf("") }; Column(Modifier.fillMaxSize()) { Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }; Column { Text(s.chat, color = Color.White, fontWeight = FontWeight.Bold); Text(if (s.languageName == "English") "Order #1250 • Online" else "الطلب #1250 • متصل الآن", color = Green, fontSize = 10.sp) } }; LazyColumn(Modifier.weight(1f).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { item { ChatBubble(if (s.languageName == "English") "Hello, I am on the way." else "مرحبًا، أنا في الطريق.", false) }; item { ChatBubble(if (s.languageName == "English") "Perfect, thank you." else "تمام، شكرًا لك.", true) } }; Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) { OutlinedTextField(text, { text = it }, Modifier.weight(1f), placeholder = { Text(if (s.languageName == "English") "Message" else "اكتب رسالة") }, singleLine = true); IconButton(onClick = { text = "" }) { Icon(Icons.Default.Send, null, tint = Orange) } } } }
@Composable private fun ChatBubble(text: String, mine: Boolean) { Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) { Surface(color = if (mine) Orange else SurfaceDark, shape = RoundedCornerShape(16.dp)) { Text(text, color = Color.White, modifier = Modifier.padding(12.dp)) } } }
@Composable private fun MetricRow(title: String, value: String, extra: String, icon: ImageVector) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(48.dp).clip(CircleShape).background(Orange.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Orange) }; Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, color = Muted); Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; Text(extra, color = Orange, fontWeight = FontWeight.Bold) } } }
@Composable private fun ProfileHeader(name: String, subtitle: String) { Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(62.dp).clip(CircleShape).background(Orange), contentAlignment = Alignment.Center) { Text(name.take(1), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }; Spacer(Modifier.width(14.dp)); Column { Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted) } } } }
@Composable private fun ProfileAction(text: String, icon: ImageVector) { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } }
@Composable private fun SimpleListScreen(title: String, listItems: List<String>, icon: ImageVector) { LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { item { Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }; items(listItems) { text -> Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(15.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Orange); Spacer(Modifier.width(12.dp)); Text(text, color = Color.White, modifier = Modifier.weight(1f)); Icon(Icons.Default.ChevronRight, null, tint = Muted) } } } } }
@Composable private fun BottomBar(selected: Int, labels: List<String>, icons: List<ImageVector>, onSelect: (Int) -> Unit) { NavigationBar(containerColor = Color(0xFF101113)) { labels.forEachIndexed { i, label -> NavigationBarItem(selected = selected == i, onClick = { onSelect(i) }, icon = { Icon(icons[i], null) }, label = { Text(label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Orange, selectedTextColor = Orange, unselectedIconColor = Muted, unselectedTextColor = Muted, indicatorColor = Color(0xFF3A2418))) } } }

private fun sectionTitle(s: UiStrings, key: String) = when (key) { "users" -> s.users; "drivers" -> s.drivers; "restaurants" -> s.restaurants; "orders" -> s.activeOrders; "applications" -> s.applications; "offers" -> s.offersCoupons; "reports" -> s.reports; else -> s.permissions }

private fun saveUser(uid: String, requestedRole: String, done: () -> Unit) { val user = auth.currentUser ?: return done(); val data = mapOf("uid" to uid, "email" to (user.email ?: ""), "phoneNumber" to (user.phoneNumber ?: ""), "requestedRole" to requestedRole, "updatedAt" to FieldValue.serverTimestamp()); db.collection("users").document(uid).set(data, SetOptions.merge()).addOnCompleteListener { FirebaseMessaging.getInstance().token.addOnSuccessListener { token -> db.collection("users").document(uid).set(mapOf("fcmToken" to token), SetOptions.merge()) }; done() } }
private fun ensureCustomerRole(uid: String, done: () -> Unit) { db.collection("users").document(uid).set(mapOf("accountType" to Role.CUSTOMER.name, "status" to "ACTIVE", "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { done() } }
private fun createApplication(uid: String, requestedRole: String, done: () -> Unit) { db.collection("applications").document(uid).set(mapOf("uid" to uid, "requestedRole" to requestedRole, "status" to "PENDING", "createdAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { done() } }
private fun resolveRole(uid: String, done: (Role?) -> Unit) { db.collection("roles").document(uid).get().addOnSuccessListener { snap -> val name = snap.getString("role"); if (!name.isNullOrBlank()) done(runCatching { Role.valueOf(name) }.getOrNull()) else db.collection("users").document(uid).get().addOnSuccessListener { us -> done(us.getString("accountType")?.let { runCatching { Role.valueOf(it) }.getOrNull() }) }.addOnFailureListener { done(null) } }.addOnFailureListener { db.collection("users").document(uid).get().addOnSuccessListener { us -> done(us.getString("accountType")?.let { runCatching { Role.valueOf(it) }.getOrNull() }) }.addOnFailureListener { done(null) } }
}
