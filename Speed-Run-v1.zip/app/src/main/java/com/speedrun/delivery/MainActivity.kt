package com.speedrun.delivery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF6A00)
private val Black = Color(0xFF101010)
private val Soft = Color(0xFFF5F5F5)

enum class Role { CUSTOMER, DRIVER, RESTAURANT, SUPERVISOR, MANAGER }

data class Restaurant(val name:String,val category:String,val city:String,val rating:Double)
val restaurants = listOf(
    Restaurant("Speed Run Kitchen","برجر","الرياض",4.8),
    Restaurant("مطعم الخليج","مشويات","الرياض",4.6),
    Restaurant("مطعم النخبة","وجبات سريعة","جدة",4.7),
    Restaurant("مطعم مذاق","مأكولات عربية","الدمام",4.5)
)

@Composable fun SpeedRunApp() {
    var lang by remember { mutableStateOf("العربية") }
    var role by remember { mutableStateOf<Role?>(null) }
    var logged by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme=lightColorScheme(primary=Orange,background=Soft)) {
        when {
            role==null -> RoleScreen(lang,{lang=it},{role=it})
            !logged -> LoginScreen(role!!,lang,{role=null},{logged=true})
            role==Role.CUSTOMER -> CustomerHome()
            role==Role.DRIVER -> DriverHome()
            role==Role.RESTAURANT -> RestaurantHome()
            role==Role.SUPERVISOR -> AdminHome("المشرف")
            else -> AdminHome("المدير")
        }
    }
}

class MainActivity:ComponentActivity(){
    override fun onCreate(b:Bundle?){super.onCreate(b);setContent{SpeedRunApp()}}
}

@Composable fun Header(title:String,sub:String){
    Column(Modifier.fillMaxWidth().background(Black).padding(18.dp)){
        Text("SPEED RUN",color=Orange,fontSize=28.sp,fontWeight=FontWeight.Black)
        Text(title,color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold)
        Text(sub,color=Color.LightGray,fontSize=12.sp)
    }
}

@Composable fun RoleScreen(lang:String,onLang:(String)->Unit,onRole:(Role)->Unit){
    Column(Modifier.fillMaxSize().background(Black).padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Spacer(Modifier.height(35.dp))
        Text("SPEED RUN",color=Orange,fontSize=40.sp,fontWeight=FontWeight.Black)
        Text("طلباتك... توصل أسرع",color=Color.White,fontSize=18.sp)
        Spacer(Modifier.height(25.dp))
        Text("اللغة / Language",color=Color.White)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.padding(8.dp)){
            listOf("العربية","English","اردو","বাংলা").forEach{FilterChip(selected=lang==it,onClick={onLang(it)},label={Text(it)})}
        }
        Spacer(Modifier.height(20.dp))
        RoleButton("العميل","طلبات الطعام وتتبع الطلب",Icons.Default.Person){onRole(Role.CUSTOMER)}
        RoleButton("السائق / المندوب","الطلبات والخريطة والأرباح",Icons.Default.DirectionsCar){onRole(Role.DRIVER)}
        RoleButton("المطعم","إدارة القائمة والطلبات",Icons.Default.Store){onRole(Role.RESTAURANT)}
        RoleButton("المشرف","التشغيل والمستخدمون",Icons.Default.AdminPanelSettings){onRole(Role.SUPERVISOR)}
        RoleButton("المدير","إدارة كاملة للمنصة",Icons.Default.ManageAccounts){onRole(Role.MANAGER)}
    }
}
@Composable fun RoleButton(t:String,s:String,icon:androidx.compose.ui.graphics.vector.ImageVector,click:()->Unit){
    Button(onClick=click,modifier=Modifier.fillMaxWidth().padding(4.dp).height(62.dp),colors=ButtonDefaults.buttonColors(containerColor=Orange),shape=RoundedCornerShape(16.dp)){
        Icon(icon,null);Spacer(Modifier.width(10.dp));Column{Text(t,fontWeight=FontWeight.Bold);Text(s,fontSize=11.sp)}}
}

@Composable fun LoginScreen(role:Role,lang:String,back:()->Unit,login:()->Unit){
    var phone by remember{mutableStateOf("")};var pass by remember{mutableStateOf("")}
    val title=when(role){Role.CUSTOMER->"دخول العميل";Role.DRIVER->"دخول السائق / المندوب";Role.RESTAURANT->"دخول المطعم";Role.SUPERVISOR->"دخول المشرف";Role.MANAGER->"دخول المدير"}
    Column(Modifier.fillMaxSize().background(Black).padding(22.dp)){
        TextButton(onClick=back){Text("رجوع",color=Orange)}
        Spacer(Modifier.height(30.dp));Text("SPEED RUN",color=Orange,fontSize=34.sp,fontWeight=FontWeight.Black)
        Text(title,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold);Text(lang,color=Color.Gray)
        Spacer(Modifier.height(25.dp))
        OutlinedTextField(phone,{phone=it},modifier=Modifier.fillMaxWidth(),label={Text("رقم الجوال")})
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(pass,{pass=it},modifier=Modifier.fillMaxWidth(),label={Text("كلمة المرور")})
        Spacer(Modifier.height(18.dp))
        Button(onClick=login,enabled=phone.isNotBlank()&&pass.isNotBlank(),modifier=Modifier.fillMaxWidth().height(55.dp),colors=ButtonDefaults.buttonColors(containerColor=Orange)){Text("تسجيل الدخول",fontWeight=FontWeight.Bold)}
    }
}

@Composable fun CustomerHome(){
    Column(Modifier.fillMaxSize()){Header("تطبيق العميل","مطاعم مختارة داخل السعودية");LazyColumn(Modifier.padding(14.dp)){
        item{Text("المطاعم القريبة",fontSize=22.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp))}
        items(restaurants){RestaurantCard(it)}
    }}
}
@Composable fun DriverHome(){
    Column(Modifier.fillMaxSize()){Header("تطبيق السائق / المندوب","تتبع الطلبات والتوصيل");LazyColumn(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Stat("حالة السائق","متاح لاستقبال الطلبات")};item{Stat("طلبات اليوم","12")};item{Stat("أرباح اليوم","285 ريال")};item{Stat("التقييم","4.9 ⭐")};item{Button(onClick={},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.buttonColors(containerColor=Orange)){Text("عرض الطلبات القريبة")}}
    }}
}
@Composable fun RestaurantHome(){
    Column(Modifier.fillMaxSize()){Header("بوابة المطعم","الطلبات والقائمة والعروض");LazyColumn(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Stat("طلبات اليوم","86")};item{Stat("المبيعات","4,280 ريال")};item{Stat("التقييم","4.8 ⭐")};item{Stat("الحالة","مفتوح")}
    }}
}
@Composable fun AdminHome(title:String){
    Column(Modifier.fillMaxSize()){Header("لوحة $title","صلاحيات منفصلة + سجل كامل للعمليات");LazyColumn(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        item{Stat("إجمالي الطلبات","1,245")};item{Stat("المستخدمون","8,642")};item{Stat("المطاعم","320")};item{Stat("السائقون النشطون","120")};item{Stat("إيرادات اليوم","28,450 ريال")}
        item{AdminItem("إدارة المستخدمين",Icons.Default.People)};item{AdminItem("إدارة السائقين",Icons.Default.DirectionsCar)};item{AdminItem("إدارة المطاعم",Icons.Default.Store)};item{AdminItem("مراقبة الطلبات",Icons.Default.LocationOn)};item{AdminItem("التقارير والإحصائيات",Icons.Default.BarChart)};item{AdminItem("الكوبونات والعروض",Icons.Default.LocalOffer)};item{AdminItem("الصلاحيات وسجل العمليات",Icons.Default.Security)}
    }}
}
@Composable fun RestaurantCard(r:Restaurant){
    Card(Modifier.fillMaxWidth().padding(vertical=5.dp),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){
        Surface(Modifier.size(55.dp),shape=RoundedCornerShape(12.dp),color=Orange){Box(contentAlignment=Alignment.Center){Text("SR",fontWeight=FontWeight.Black)}}
        Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold);Text("${r.category} • ${r.city}",color=Color.Gray,fontSize=12.sp);Text("⭐ ${r.rating}",color=Orange)}
        Icon(Icons.Default.ChevronRight,null)
    }}
}
@Composable fun Stat(t:String,v:String){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(16.dp)){Text(t,color=Color.Gray);Text(v,color=Orange,fontSize=24.sp,fontWeight=FontWeight.Black)}}}
@Composable fun AdminItem(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Icon(icon,null,tint=Orange);Spacer(Modifier.width(12.dp));Text(t,fontWeight=FontWeight.Bold);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}}
